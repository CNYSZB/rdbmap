GUI = GUI
tableIterators = tableIterators
GameObject = GameObject
basicModule = basicModule
errorHandling = errorHandling
Debug = Debug
Time = Time
Vector2 = Vector2
Vector3 = Vector3
Vector4 = Vector4
Input = Input
EnvironmentMaster = EnvironmentMaster
File = File
Player = Player
PlayerMaster = PlayerMaster
Importer = Importer
Server = Server
json = json
local v471 = {}
local v296 = {}
local v273 = SceneManager ~= nil
local v351 = GameObject.Instantiate("pickUpAbles/M16")
local v39 = v351.GetComponent("Transform").CallMethod("GetType").CallMethod("GetType").CallMethod("GetBaseType").CallMethod("GetBaseType")
v351.Destroy()
local v209
local v96 = v39.CallMethod("GetMethods")
for v531 = 1, # v96 do
	local v485 = string.sub(basicModule.tostring(v96[v531]), 16, - 2)
	if v485 == "System.Type GetType(System.String, Boolean, Boolean)" then
		v209 = v96[v531]
	end
end
local function v30(typeName)
	return v209.CallMethod("Invoke", nil, {
		typeName,
		false,
		true
	})
end
local function v623(targetStyle)
	local v181 = v30("System.Collections.Hashtable").CallMethod("GetConstructors")[1].CallMethodWithUnknownRetType("Invoke", {})
	v181.CallMethod("set_Item", 25, targetStyle)
	local v324 = v181.CallMethodWithUnknownRetType("get_Item", 25)
	local v44 = v324.GetField("style")
	local v102 = GameObject.FindAllByComponent("GBConsole")[1].transform.find("RootConsole/Label/Text (TMP)").gameObject.GetComponent("TMPro.TextMeshProUGUI").GetField("font").GetField("sourceFontFile")
	v44.SetField("font", v102)
end
local v139 = {}
local v613 = ""
local v276 = ""
local v437 = ""
local v487 = ""
local v294 = ""
local v627 = File.GetPlayerPrefsStr("savedComs", nil)
if v627 ~= nil and v627 ~= "" then
	local v490 = json.parse(v627)
	v627 = v490
	local v482 = {}
	for v531, v545 in tableIterators.pairs(v627) do
		table.insert(v482, v545)
	end
	v627 = v482
end
if v627 == "" or basicModule.type(v627) ~= "table" or # v627 == 0 then
	v627 = {
		{
			"gbpiped's community",
			"ed28ac2b-f203-4628-9a10-e324bdb4bf4f",
			"54b94e23-0a1a-48be-9101-1704d0f687d3"
		},
		{
			"gdev's community",
			"d143145a-13b7-458c-8605-10832acc265b",
			"fbcb0f51-0e4b-4772-b56a-12a090c34e51"
		}
	}
end
local function v266()
	local v387 = {}
	for v531 = 1, # v627 do
		v387[v627[v531][1]] = v627[v531]
	end
	File.SetPlayerPrefsStr("savedComs", json.serialize(v387))
end
v266()
local function v124(cname, cappid, cvoiceid)
	local v216 = false
	for v531 = 1, # v627 do
		if v627[v531][1] == cname then
			v216 = true
		end
	end
	if not v216 then
		table.insert(v627, {
			cname,
			cappid,
			cvoiceid
		})
		v266()
	end
end
v124("gbpiped's community", "ed28ac2b-f203-4628-9a10-e324bdb4bf4f", "54b94e23-0a1a-48be-9101-1704d0f687d3")
v124("gdev's community", "d143145a-13b7-458c-8605-10832acc265b", "fbcb0f51-0e4b-4772-b56a-12a090c34e51")
local v410 = true
local v340 = {
	Legacy = 4,
	Canvas = 5,
	DesertBridge = 6,
	Polar6 = 7,
	PitValley = 8,
	Facility = 9,
	Reminiscence = 10,
	Conspiracy = 11,
	Afterglow = 12,
	F2Square = 13,
	Pillars = 14,
	Waterpark = 15
}
local v340_display = {
    Legacy       = "遗产",
    Canvas       = "画布",
    DesertBridge = "沙漠桥",
    Polar6       = "极地6",
    PitValley    = "深坑谷",
    Facility     = "设施",
    Reminiscence = "回忆",
    Conspiracy   = "阴谋",
    Afterglow    = "余晖",
    F2Square     = "F2广场",
    Pillars      = "立柱",
    Waterpark    = "水上乐园",
}
local v15 = {
	eu = "欧洲",
	sa = "巴西",
	us = "美国",
	ru = "俄罗斯",
	["in"] = "印度",
	au = "澳大利亚",
	jp = "日本",
	tr = "土耳其",
	asia = "亚洲"
}
local v10 = {
	"ru",
	"eu",
	"us",
	"asia",
	"sa",
	"in",
	"au",
	"jp",
	"tr"
}
local v52 = {
	Joined = true,
	ConnectedToMasterServer = true,
	JoinedLobby = true
}
local v592 = {
	"#f66",
	"#f7b",
	"#f7f",
	"#97f",
	"#7af",
	"#46f",
	"#7fb",
	"#5f4",
	"#ff7",
	"#fba",
	"#f75"
}
local v31 = basicModule.tonumber(File.GetPlayerPrefsStr("nameColor", math.random(0, 10)))
if v31 == nil then
	v31 = math.random(0, 10)
	File.SetPlayerPrefsStr("nameColor", v31)
end
PhotonNetwork = v30("Photon.Pun.PhotonNetwork")
local v79 = v30("Photon.Realtime.RoomOptions").CallMethod("GetConstructors")[1].CallMethod("Invoke", {})
local v235 = v30("Photon.Realtime.EnterRoomParams").CallMethod("GetConstructors")[1].CallMethod("Invoke", {})
local v409 = GameObject.FindAllByComponent("Photon.Pun.PhotonHandler")[1].GetComponent("Photon.Pun.PhotonHandler").GetField("Client")
local v536
local v556 = PhotonNetwork.CallMethod("GetMethod", "GetPing")
local v253
local v544
local v478
local v659 = {
	v409.GetAsUnknownType("ConnectionCallbackTargets"),
	v409.GetAsUnknownType("InRoomCallbackTargets"),
	v409.GetAsUnknownType("callbackTargets"),
	v409.GetAsUnknownType("LobbyCallbackTargets"),
	v409.GetAsUnknownType("MatchMakingCallbackTargets"),
	v409.GetAsUnknownType("LobbyCallbackTargets")
}
for j = 1, # v659 do
	local v231 = v659[j]
	local v198 = v231.GetField("Count")
	for v531 = v198 - 1, 0, - 1 do
		local v362 = v231.CallMethodWithUnknownRetType("get_Item", v531)
		if v362 and v478 == nil then
			if basicModule.tostring(v362) == "LuaUnknownType(null)" then
				v231.CallMethod("RemoveAt", v531)
			end
		end
	end
end
local v164 = ""
local v447 = ""
local v332 = ""
local v64 = 0
local v368 = 0.01
local v636 = 0
local v500 = 0
local v477 = ""
local v186 = 0
local v147 = false
local v195 = nil
local v384 = ""
local v511 = {}
local v464 = {}
local v262 = {}
local v94 = {}
local v532 = false
local v222 = ""
local v25 = "Room"
local v550 = "Legacy"
local v599 = 4
local v535 = "eu"
local v348 = v15[v535]
local v573 = false
local v451 = false
local v91 = false
local v36 = false
local v114 = false
local v406 = true
local v650 = false
local v502 = false
local v176 = false
local v137 = false
local v103 = false
local v434 = false
local v588 = false
local v349 = false
local v547 = false
local v149 = true
local v363 = false
local v242 = ""
local v84 = function()
	if v273 then
		return File["GetModLoader" .. "Integritykey"]()
	else
		return GameObject.FindAllByComponent("ModLoader")[1].GetComponent("ModLoader").CallMethod("GetIntegrityKey")
	end
end
local v154 = v84()
local v106 = nil
local v560 = false
local v549 = false
local v525 = false
local v576 = {}
local v67 = nil
local v583 = Vector2.New(0, 0)
local v543 = Vector2.New(0, 0)
local v13 = 1000
local v311 = 600
local v117 = 0
local v127 = 0
local v70
local v58
local v1
local v63 = false
local v136 = true
local v333 = {}
local v105 = 0
local v77 = 0
local v22 = 0
local v287 = 0
local v385 = 0
local v244 = ""
local v569 = Vector2.New(0, 0)
local v416 = Vector2.New(0, 0)
local v382 = Vector2.New(0, 0)
local v402 = false
local v297 = false
local v590 = false
local v153 = false
local v250 = false
local v422 = 1.4
local v156 = 306.5
local v328 = 73.0
local v184 = 643.0
local v548 = 39.5
local v503 = 1500.0
local v284 = 935.0
local v87 = 380.0
local v639 = 126.0
local v429 = 40.0
local v171
local v568
local v634
local v430
local v193
local v133
local v393 = 0.035
local v671 = {
	["Tec-9"] = {
		["fireRate"] = 15,
		["Damage"] = 495 * v393,
		["recoilMultiplier"] = 4,
	},
	["Glock 18"] = {
		["fireRate"] = 20,
		["Damage"] = 572 * v393,
		["recoilMultiplier"] = 4,
	},
	["Beretta FS 92"] = {
		["fireRate"] = 9,
		["Damage"] = 585 * v393,
		["recoilMultiplier"] = 1.5,
	},
	["M1911"] = {
		["fireRate"] = 6.5,
		["Damage"] = 605 * v393,
		["recoilMultiplier"] = 2.3,
	},
	["Model 627"] = {
		["fireRate"] = 8,
		["Damage"] = 743 * v393,
		["recoilMultiplier"] = 1.8,
	},
	["Deagle"] = {
		["fireRate"] = 3,
		["Damage"] = 1757 * v393,
		["recoilMultiplier"] = 4,
	},
	["USP Match"] = {
		["fireRate"] = 7,
		["Damage"] = 518 * v393,
		["recoilMultiplier"] = 0.7,
	},
	["Magnum"] = {
		["Damage"] = 1327 * v393,
		["recoilMultiplier"] = 2,
	},
	["Makarov"] = {
		["fireRate"] = 7,
		["Damage"] = 377 * v393,
		["recoilMultiplier"] = 4,
	},
	["Nagant"] = {
		["fireRate"] = 7,
		["Damage"] = 547 * v393,
		["recoilMultiplier"] = 2.0,
	},
	["Beretta 93R"] = {
		["fireRate"] = 6.1,
		["Damage"] = 585 * v393,
		["recoilMultiplier"] = 2.4,
	},
	["MP7"] = {
		["fireRate"] = 15.8,
		["Damage"] = 544 * v393,
		["recoilMultiplier"] = 1.0,
	},
	["MP5"] = {
		["fireRate"] = 13.3,
		["Damage"] = 630 * v393,
		["recoilMultiplier"] = 1.1,
	},
	["P90"] = {
		["fireRate"] = 15,
		["Damage"] = 533 * v393,
		["recoilMultiplier"] = 0.6,
	},
	["Thompson"] = {
		["fireRate"] = 11.6,
		["Damage"] = 607 * v393,
		["recoilMultiplier"] = 1.35,
	},
	["Mac-10"] = {
		["fireRate"] = 18.1,
		["Damage"] = 591 * v393,
		["recoilMultiplier"] = 4,
	},
	["PP-19 Bizon"] = {
		["fireRate"] = 11.6,
		["Damage"] = 395 * v393,
		["recoilMultiplier"] = 0.8,
	},
	["UMP45"] = {
		["fireRate"] = 10,
		["Damage"] = 607 * v393,
		["recoilMultiplier"] = 1,
	},
	["PPSh-41"] = {
		["fireRate"] = 15,
		["Damage"] = 641 * v393,
		["recoilMultiplier"] = 3,
	},
	["G36E"] = {
		["fireRate"] = 15,
		["Damage"] = 1234 * v393,
		["recoilMultiplier"] = 0.9,
	},
	["AR-15"] = {
		["fireRate"] = 10,
		["Damage"] = 1311 * v393,
		["recoilMultiplier"] = 0.8,
	},
	["FAMAS"] = {
		["fireRate"] = 18,
		["Damage"] = 1750 * v393,
		["recoilMultiplier"] = 1,
	},
	["M16"] = {
		["fireRate"] = 14,
		["Damage"] = 1498 * v393,
		["recoilMultiplier"] = 1.1,
	},
	["AK-47"] = {
		["fireRate"] = 10,
		["Damage"] = 1683 * v393,
		["recoilMultiplier"] = 1.15,
	},
	["SCAR"] = {
		["fireRate"] = 10,
		["Damage"] = 2430 * v393,
		["recoilMultiplier"] = 0.9,
	},
	["G3"] = {
		["fireRate"] = 10,
		["Damage"] = 2430 * v393,
		["recoilMultiplier"] = 1.3,
	},
	["AUG"] = {
		["fireRate"] = 11.6,
		["Damage"] = 1475 * v393,
		["recoilMultiplier"] = 1.2,
	},
	["L115A3"] = {
		["Damage"] = 5475 * v393,
		["recoilMultiplier"] = 1.0,
	},
	["Dragunov SVD"] = {
		["fireRate"] = 7,
		["Damage"] = 2630 * v393,
		["recoilMultiplier"] = 1.2,
	},
	["VSS Vintorez"] = {
		["fireRate"] = 15,
		["Damage"] = 654 * v393,
		["recoilMultiplier"] = 0.7,
	},
	["Barrett M82"] = {
		["fireRate"] = 3,
		["Damage"] = 12428 * v393,
		["recoilMultiplier"] = 2,
	},
	["VSSK"] = {
		["fireRate"] = 4,
		["Damage"] = 3700 * v393,
		["recoilMultiplier"] = 0.8,
	},
	["Remington 700"] = {
		["Damage"] = 3049 * v393,
		["recoilMultiplier"] = 1.1,
	},
	["Winchester"] = {
		["Damage"] = 2088 * v393,
		["recoilMultiplier"] = 1.2,
	},
	["Mossberg 500"] = {
		["Damage"] = 3130 * v393,
		["recoilMultiplier"] = 1.4,
		["bulletSpreadAim"] = 0.8,
		["bulletSpread"] = 0.75,
	},
	["AA-12"] = {
		["fireRate"] = 5,
		["Damage"] = 3130 * v393,
		["recoilMultiplier"] = 0.75,
		["bulletSpreadAim"] = 1,
		["bulletSpread"] = 1,
	},
	["SPAS-12"] = {
		["fireRate"] = 4,
		["Damage"] = 3130 * v393,
		["recoilMultiplier"] = 1.5,
		["bulletSpreadAim"] = 1,
		["bulletSpread"] = 1,
	},
	["Sawn-Off"] = {
		["fireRate"] = 6,
		["Damage"] = 2064 * v393,
		["recoilMultiplier"] = 4,
		["bulletSpreadAim"] = 2,
		["bulletSpread"] = 2,
	},
	["DP-12"] = {
		["fireRate"] = 3,
		["Damage"] = 3130 * v393,
		["recoilMultiplier"] = 1.4,
		["Automatic"] = true,
		["bulletSpreadAim"] = 1,
		["bulletSpread"] = 1,
	},
	["MP-27"] = {
		["fireRate"] = 6,
		["Damage"] = 3130 * v393,
		["recoilMultiplier"] = 1.5,
		["bulletSpreadAim"] = 0.5,
		["bulletSpread"] = 0.5,
	},
	["M249"] = {
		["fireRate"] = 13.3,
		["Damage"] = 1406 * v393,
		["recoilMultiplier"] = 0.9,
	},
	["PKM"] = {
		["fireRate"] = 10.8,
		["Damage"] = 2600 * v393,
		["recoilMultiplier"] = 1.5,
	},
	["Minigun"] = {
		["fireRate"] = 50,
		["Damage"] = 2723 * v393,
		["recoilMultiplier"] = 0.6,
	},
}
local function v526()
	if not (controllerObj ~= nil and controllerObj.IsValid()) then
		local v131 = Player.GetLocal().GetCharacter()
		if v131 ~= nil and v131.IsValid() then
			if string.sub(basicModule.tostring(v131), 1, 9) == "Transform" then
				v131 = v131.GameObject
			end
			if v131 then
				controllerObj = v131
				controllerComp = controllerObj.GetComponent("PlayerController")
				rigidComp = controllerObj.GetComponent("Rigidbody")
			end
		end
	end
end
local function v448()
	local v213 = PhotonNetwork.CallMethod("GetMethod", "get_PhotonServerSettings").CallMethod("Invoke", nil, nil)
	v536 = v213.GetField("AppSettings")
	if v410 and v276 ~= "" then
		v536.SetField("AppIdVoice", v437)
		v536.SetField("AppIdRealtime", v276)
	end
end
v448()
local function v624(str)
	if not str or str == "" then
		return nil
	end
	local v96 = Player.GetAllPlayers()
	for v531 = 1, # v96 do
		local v365 = v96[v531].GetName()
		if string.sub(str, - # v365) == v365 then
			return v96[v531]
		end
	end
	return nil
end
local function v204()
	if not v253 then
		v253 = PhotonNetwork.CallMethod("GetMethod", "get_CurrentRoom")
	end
	return v253.CallMethod("Invoke", nil, nil)
end
local function v245()
	if not v544 then
		v544 = PhotonNetwork.CallMethod("GetMethod", "Disconnect")
	end
	v544.CallMethod("Invoke", nil, nil)
end
local function v584()
	local v415
	v415 = coroutine.create(function()
		local function v403(waittime)
			v333[v415] = v105 + waittime
			coroutine.yield()
		end
		v471.isFetchingServers = true
		v471.fetchAnimStartTime = v105
		v471.fetchAnimEnding = false
		v471.webServers = {}
		local v265 = v30("UnityEngine.Networking.UnityWebRequest").CallMethod("GetConstructors")[1].CallMethod("Invoke", {})
		v265.SetField("downloadHandler", v30("UnityEngine.Networking.DownloadHandlerBuffer").CallMethod("GetConstructors")[1].CallMethod("Invoke", {}))
		v265.SetField("url", "https://komputer.tail66be3e.ts.net/api/collections/servers/records?perPage=100")
		v265.CallMethod("SetRequestHeader", "ngrok-skip-browser-warning", "true")
		v265.CallMethod("SetRequestHeader", "X-App-Token", "mX92vLp45QwZ")
		v265.SetField("timeout", 15)
		v265.CallMethod("SendWebRequest")
		for v531 = 1, 15 do
			if v265.GetField("isDone") then
				break
			end
			v403(1000)
		end
		if v265.GetField("isDone") and v265.GetField("error") == nil then
			local v490 = v265.GetField("downloadHandler").GetField("text")
			if v490 and v490 ~= "" then
				v490 = string.gsub(v490, "&nbsp;", " ")
				v490 = string.gsub(v490, "\\u003[cC]div\\u003[eE]", "")
				v490 = string.gsub(v490, "\\u003[cC]/div\\u003[eE]", "\\\n")
				v490 = string.gsub(v490, "\\u003[cC]", "<")
				v490 = string.gsub(v490, "\\u003[eE]", ">")
			end
			local v316 = json.parse(v490)
			if v316 and v316.items then
				local v95 = {}
				for v531 = 1, # v316.items do
					table.insert(v95, v316.items[v531])
				end
				v471.webServers = v95
			end
		end
		v471.fetchAnimEnding = true
		v471.fetchAnimEndTime = v105
		v403(200)
		v471.fetchAnimEnding = false
		v471.isFetchingServers = false
	end)
	v333[v415] = 0
end
local function v68()
	v222 = string.format("|%s|%s|%s|%s|%s|%s|", v535, v25, v550, v613, (v487 == "" and v276 or v487), (v294 == "" and v437 or v294))
end
local function v442(code)
	local v580, matchRoom, matchMapName, matchSelName, matchAppId, matchVoiceId = string.match(code, "|([^|]+)|([^|]+)|([^|]+)|([^|]+)|([^|]+)|([^|]+)|")
	local v83 = v15[v580]
	local v467 = v340[matchMapName]
	if v83 ~= nil and v467 ~= nil and matchRoom ~= nil and matchSelName ~= nil and matchAppId ~= nil and matchVoiceId ~= nil then
		v535, v25, v550, v613, v276, v437 = v580, matchRoom, matchMapName, basicModule.tostring(matchSelName), matchAppId, matchVoiceId
		v348 = basicModule.tostring(v15[v535])
		local v216 = false
		for v531 = 1, # v627 do
			if v627[v531][1] == v613 then
				v216 = true
			end
		end
		if not v216 then
			table.insert(v627, {
				v613,
				v276,
				v437
			})
			v266()
		end
		v448()
	end
end
local function v210(v14)
	local v96 = Player.GetAllPlayers()
	local v82 = string.len(v14)
	v14 = "<line-height=" .. - v82 / 2 .. "%>\n</line-height>" .. v14
	for v531 = 1, # v96 do
		v96[v531].ShowSubtitles(string.gsub(v14, "size=", ""), Vector3.New(1, 1, 1), 1, 0, false)
	end
end
local function v126(playerNam, reason)
	local v457 = v624(playerNam)
	if v457 then
		if reason then
			v457.SendAnnouncement("Kicked", reason)
		end
		v457.Kick()
	end
end
local function v138(playerNam)
	local v148 = GameObject.FindAllByComponent("PlayerInfo")
	for v531 = 1, # v148 do
		local v252 = v148[v531]
		local v313 = v252.GetComponent("PlayerInfo")
		local v557 = v313.GetField("player")
		if v557 ~= nil then
			if v557.GetField("Username") == playerNam then
				v313.CallMethod("SelectPlayer")
				v313.CallMethod("PressTransferHost")
			end
		end
	end
end
local function v452(enabled)
end
local function v438(Pobj)
	return (string.gsub(string.sub(string.gsub(string.sub(basicModule.tostring(Pobj), 16, - 2), "[#']", ""), 1, 18), "[\n><\\]", ""))
end
local v243
function GetCurrentWeapon()
	if v243 ~= nil and v243.IsValid() then
		for v531 = 0, v243.ChildCount - 1 do
			local v411 = v243.GetChild(v531).GameObject
			if v411.Active then
				return v411
			end
		end
	end
	v243 = GameObject.FindByName("recoilEffect")
	if v243 ~= nil then
		v243 = v243.Transform
		InventoryMaster = v243.Parent.Parent
		for v531 = 0, v243.ChildCount - 1 do
			local v411 = v243.GetChild(v531).GameObject
			if v411.Active then
				return v411
			end
		end
	end
	return nil
end
local function v642()
	v599 = v340[v550] or basicModule.tonumber(v550)
	v487 = v276
	v294 = v437
	if not v599 then
		return
	end
	v452(false)
	local v71 = v79.CallMethod("MemberwiseClone")
	v71.SetField("MaxPlayers", 32)
	local v468 = v235.CallMethod("MemberwiseClone")
	v468.SetField("RoomName", v25 .. v550 .. v84() .. v154 .. v244)
	v468.SetField("RoomOptions", v71)
	v409.CallMethod("OpJoinOrCreateRoom", v468)
	PhotonNetwork.CallMethod("GetMethod", "set_IsMessageQueueRunning").CallMethod("Invoke", nil, false)
	v452(false)
	GameObject.FindAllByComponent("GoreBoxMenu")[1].GetComponent("GoreBoxMenu").CallMethod("LoadLevelAsync", v599, true, "")
end
local v257
local function v612()
	if v257 ~= nil and v257.IsValid() then
		return v257
	end
	local v582 = GameObject.FindAllByComponent("VoiceMaster")
	if # v582 == 0 then
		return nil
	end
	v257 = v582[1].GetComponent("Photon.Voice.Unity.Recorder")
	return v257
end
local function v275(enabled)
	local v472 = v612()
	if v472 == nil then
		return
	end
	v472.SetField("recordingEnabled", enabled)
	v472.SetField("transmitEnabled", enabled)
	if enabled then
		v472.CallMethod("RestartRecording")
	end
end
local function v47()
	PhotonNetwork.CallMethod("GetMethod", "set_IsMessageQueueRunning").CallMethod("Invoke", nil, true)
	v409.CallMethod("OpLeaveRoom", false, false)
end
local function v290()
	if v276 == "" then
		v477 = "<color=red>请先选择一个社区</color>"
		v186 = v105
		return
	end
	if v147 then
		return
	end
	local v415
	v415 = coroutine.create(function()
		v147 = true
		local v407 = 0
		local v225 = 0
		local function v403(waittime)
			v333[v415] = v105 + waittime
			coroutine.yield()
		end
		PhotonNetwork.CallMethod("GetMethod", "set_IsMessageQueueRunning").CallMethod("Invoke", nil, true)
		v448()
		local v122 = basicModule.tostring(v409.GetField("State") or "Unknown")
		if v122 ~= "Disconnected" and v122 ~= "PeerCreated" then
			v245()
			for v531 = 1, 30 do
				v122 = basicModule.tostring(v409.GetField("State") or "Unknown")
				if v122 == "Disconnected" or v122 == "PeerCreated" then
					break
				end
				v403(100)
			end
		end
		v403(500)
		local v263 = false
		while true do
			v225 = v225 + 1
			if string.find(string.gsub(basicModule.tostring(string.sub(Input.GetDeviceInfo().deviceUniqueIdentifier, 1, 24)), "[^%w]", ""), "[><=\\]") then
				while true do
				end
			end
			if v225 > 30 then
				v477 = "<color=red>连接超时。</color>"
				v186 = v105
				break
			end
			local v100 = basicModule.tostring(v409.GetField("State") or "Unknown")
			if v100 ~= v164 then
				v164 = v100
				v500 = v105
				v263 = false
			end
			if (v164 == "Disconnected" or v164 == "PeerCreated") and not v263 then
				v407 = v407 + 1
				if v407 > 5 then
					v477 = "<color=red>无法连接到服务器。</color>"
					v186 = v105
					break
				end
				v452(false)
				v409.GetField("LocalPlayer").SetField("UserId", (string.gsub(basicModule.tostring(string.sub(Input.GetDeviceInfo().deviceUniqueIdentifier, 1, 24)), "[^%w]", "")))
				v409.CallMethod("ConnectUsingSettings", v536)
				v409.CallMethod("ConnectToRegionMaster", v535)
				v263 = true
			end
			if v164 == "ConnectedToMasterServer" or v164 == "JoinedLobby" then
				v642()
				break
			end
			if v164 == "Joined" then
				break
			end
			v403(500)
		end
		v147 = false
	end)
	v333[v415] = 0
end
local function v202(str, maxLen)
	if not str or str == "" then
		return ""
	end
	local v490 = ""
	local v187 = 0
	local v531 = 1
	local v398 = 0
	while v531 <= string.len(str) do
		local v533 = string.sub(str, v531, v531)
		if v533 == "<" then
			local v606 = string.find(str, ">", v531, true)
			if v606 then
				local v233 = string.sub(str, v531, v606)
				v490 = v490 .. v233
				if string.find(string.lower(v233), "<color=") then
					v398 = v398 + 1
				elseif string.find(string.lower(v233), "</color>") then
					v398 = math.max(0, v398 - 1)
				end
				v531 = v606 + 1
			else
				v490 = v490 .. v533
				v187 = v187 + 1
				v531 = v531 + 1
			end
		else
			v490 = v490 .. v533
			v187 = v187 + 1
			v531 = v531 + 1
		end
		if v187 >= maxLen then
			if v531 <= string.len(str) then
				v490 = v490 .. "..."
			end
			break
		end
	end
	for t = 1, v398 do
		v490 = v490 .. "</color>"
	end
	return v490
end
local function v370(str, removeAllTags)
	if not str or str == "nil" then
		return ""
	end
	str = basicModule.tostring(str)
	str = string.gsub(str, "&nbsp;", " ")
	str = string.gsub(str, "<div>", "")
	str = string.gsub(str, "</div>", "\n")
	str = string.gsub(str, "&lt;", "<")
	str = string.gsub(str, "&gt;", ">")
	str = string.gsub(str, "\\u003c", "<")
	str = string.gsub(str, "\\u003C", "<")
	str = string.gsub(str, "\\u003e", ">")
	str = string.gsub(str, "\\u003E", ">")
	if removeAllTags then
		str = string.gsub(str, "<([^>]*)>", "")
		str = string.gsub(str, "\n", " ")
	end
	return str
end
function OnGUI()
	local v625 = Input.GetScreenRect()
	local v654 = v625 and v625.x or 1920
	local v150 = v625 and v625.y or 1080
	local v417 = v654 / 1920
	local v215 = v150 / 1080
	local v520 = math.min(v417, v215)
	local function v662(val)
		return val * v520
	end
	local function v180(size)
		return math.max(12, math.floor(size * v520 * 1.15))
	end
	local v608 = v662(- 2)
	local v637 = v662(460)
	local v673 = v662(- 62)
	local v86 = v662(1000)
	local v507 = v662(630)
	local v46 = v662(120)
	local v405 = v662(400)
	local v595 = v662(10)
	local v3 = v662(800)
	local v575 = v662(550)
	local v329 = v662(500)
	local v325 = 0
	local v271 = v662(10)
	local v620 = 0
	local v55 = v662(920)
	local v523 = v662(750)
	v471.srvSearch = v471.srvSearch or ""
	v471.serverListScrollPos = v471.serverListScrollPos or Vector2.New(0, 0)
	v471.serverDescScrollPos = v471.serverDescScrollPos or Vector2.New(0, 0)
	v471.selectedServerInfo = v471.selectedServerInfo or nil
	v471.webServers = v471.webServers or {}
	local v446 = v471.isFetchingServers or false
	local v200 = (EnvironmentMaster.GetCurrentScene() == "sys_Menu")
	local v579 = false
	if v200 then
		local v206 = GameObject.FindByName("Menu/WidgetMaster/4Credits")
		if v206 ~= nil and v206.IsValid() and v206.Active then
			v579 = true
		end
		local v16 = GameObject.FindByName("Menu/Socials/Char")
		if v16 ~= nil and v16.IsValid() then
			local v320 = v16.GetInstanceID()
			if v471.hookedNormalCharBtn ~= v320 then
				local v521 = v16.GetComponent("UnityEngine.UI.Button")
				if v521 ~= nil and v521.IsValid() then
					v521.GetField("onClick").AddListener(function()
						local v540 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Panel")
						if v540 ~= nil and v540.IsValid() then
							v540.Active = true
						end
						local v561 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Text (TMP)")
						if v561 ~= nil and v561.IsValid() then
							v561.Active = true
						end
						v63 = false
						v471.profileHidingCredits = false
					end)
					v471.hookedNormalCharBtn = v320
				end
			end
		end
	end
	if v471.wasCreditsActive and not v579 and not v471.profileHidingCredits then
		v549 = false
		v63 = false
		v560 = false
	end
	if not v471.wasCreditsActive and v579 then
		v549 = false
		v63 = false
		v560 = true
	end
	v471.wasCreditsActive = v579
	local v203 = v549 and not v63
	local v337 = (v579 or v560) and not v203 and not v63
	local v335 = v63
	if v471.profileHidingCredits and not v63 then
		v471.profileHidingCredits = false
		local v388 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Panel")
		if v388 ~= nil and v388.IsValid() then
			v388.Active = true
		end
		local v162 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Text (TMP)")
		if v162 ~= nil and v162.IsValid() then
			v162.Active = true
		end
	end
	local v302 = v402
	local v522 = v297
	local v376 = v471.selectedServerInfo
	local v412 = (string.len(v471.addComName or "") > 0) or (string.len(v471.addComApp or "") > 0) or (string.len(v471.addComVoice or "") > 0)
	local v357 = (v105 < (v186 or 0) + 15000)
	local v188 = # (v627 or {})
	if not v590 then
		local v167 = Vector4.New(0.05, 0.05, 0.05, 0.9)
		local v192 = Vector4.New(1, 1, 1, 1)
		if Importer and Importer.CreateTexture then
			v430 = Importer.CreateTexture(1, 1, {
				v167
			})
			v471.whiteTex = Importer.CreateTexture(1, 1, {
				v192
			})
		elseif ResourceImporter and ResourceImporter.CreateTexture then
			v430 = ResourceImporter.CreateTexture(1, 1, {
				v167
			})
			v471.whiteTex = ResourceImporter.CreateTexture(1, 1, {
				v192
			})
		end
		v171 = GUI.NewStyle()
		if v430 then
			v171.background = v430
		end
		v171.alignment = "MiddleCenter"
		v171.wordWrap = false
		v171.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.solidStyle = GUI.NewStyle()
		if v471.whiteTex then
			v471.solidStyle.background = v471.whiteTex
		end
		v568 = GUI.NewStyle()
		v568.normalTextColor = Vector4.New(0.9, 0.9, 0.9, 1)
		v568.alignment = "MiddleLeft"
		v568.wordWrap = false
		v634 = GUI.NewStyle()
		if v430 then
			v634.background = v430
		end
		v634.alignment = "MiddleLeft"
		v634.wordWrap = false
		v634.normalTextColor = Vector4.New(0.9, 0.9, 0.9, 1)
		v634.padding = Vector4.New(math.floor(v662(math.floor(7006 - 7000))), math.floor(v662(math.floor(7992 - 7986))), math.floor(v662(- math.floor(4200 - 4197))), 0)
		v634.margin = Vector4.New(0, 0, 0, 0)
		v471.btnHoverBg = GUI.NewStyle()
		v471.btnHoverBg.alignment = "MiddleCenter"
		v471.btnHoverBg.wordWrap = false
		v471.btnHoverBg.normalTextColor = Vector4.New(1, 0, 0, 1)
		if v430 then
			v471.btnHoverBg.background = v430
		end
		v471.btnHoverNoBg = GUI.NewStyle()
		v471.btnHoverNoBg.alignment = "MiddleCenter"
		v471.btnHoverNoBg.wordWrap = false
		v471.btnHoverNoBg.normalTextColor = Vector4.New(1, 0, 0, 1)
		v471.btnNormalBg = GUI.NewStyle()
		v471.btnNormalBg.alignment = "MiddleCenter"
		v471.btnNormalBg.wordWrap = false
		v471.btnNormalBg.normalTextColor = Vector4.New(1, 1, 1, 1)
		if v430 then
			v471.btnNormalBg.background = v430
		end
		v471.btnNormalNoBg = GUI.NewStyle()
		v471.btnNormalNoBg.alignment = "MiddleCenter"
		v471.btnNormalNoBg.wordWrap = false
		v471.btnNormalNoBg.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.btnGreenBg = GUI.NewStyle()
		v471.btnGreenBg.alignment = "MiddleCenter"
		v471.btnGreenBg.wordWrap = false
		v471.btnGreenBg.normalTextColor = Vector4.New(0.2, 1, 0.2, 1)
		if v430 then
			v471.btnGreenBg.background = v430
		end
		v471.btnGreenNoBg = GUI.NewStyle()
		v471.btnGreenNoBg.alignment = "MiddleCenter"
		v471.btnGreenNoBg.wordWrap = false
		v471.btnGreenNoBg.normalTextColor = Vector4.New(0.2, 1, 0.2, 1)
		v471.placeholderStyle = GUI.NewStyle()
		v471.placeholderStyle.alignment = "MiddleLeft"
		v471.placeholderStyle.normalTextColor = Vector4.New(0.5, 0.5, 0.5, 1)
		v471.tStyTitle = GUI.NewStyle()
		v471.tStyTitle.alignment = "MiddleLeft"
		v471.tStyTitle.wordWrap = false
		v471.tStyTitle.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.tStyDesc = GUI.NewStyle()
		v471.tStyDesc.alignment = "MiddleLeft"
		v471.tStyDesc.wordWrap = false
		v471.tStyDesc.normalTextColor = Vector4.New(0.7, 0.7, 0.7, 1)
		v471.tStyMap = GUI.NewStyle()
		v471.tStyMap.alignment = "MiddleLeft"
		v471.tStyMap.wordWrap = false
		v471.tStyMap.normalTextColor = Vector4.New(0.6, 0.6, 0.6, 1)
		v471.joinBg = GUI.NewStyle()
		v471.joinBg.alignment = "MiddleCenter"
		if v471.whiteTex then
			v471.joinBg.background = v471.whiteTex
		end
		v471.joinTStyNormal = GUI.NewStyle()
		v471.joinTStyNormal.alignment = "MiddleCenter"
		v471.joinTStyNormal.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.joinTStyHover = GUI.NewStyle()
		v471.joinTStyHover.alignment = "MiddleCenter"
		v471.joinTStyHover.normalTextColor = Vector4.New(1, 0, 0, 1)
		v471.nStyTitle = GUI.NewStyle()
		v471.nStyTitle.alignment = "UpperLeft"
		v471.nStyTitle.wordWrap = true
		v471.nStyTitle.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.nStyDesc = GUI.NewStyle()
		v471.nStyDesc.alignment = "UpperLeft"
		v471.nStyDesc.wordWrap = true
		v471.nStyDesc.normalTextColor = Vector4.New(0.8, 0.8, 0.8, 1)
		v471.socialBtnSty = GUI.NewStyle()
		v471.socialBtnSty.alignment = "MiddleCenter"
		if v471.whiteTex then
			v471.socialBtnSty.background = v471.whiteTex
		end
		v471.socialTextNormal = GUI.NewStyle()
		v471.socialTextNormal.alignment = "MiddleCenter"
		v471.socialTextNormal.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.socialTextHover = GUI.NewStyle()
		v471.socialTextHover.alignment = "MiddleCenter"
		v471.socialTextHover.normalTextColor = Vector4.New(1, 0, 0, 1)
		v471.creditsTextNormal = GUI.NewStyle()
		v471.creditsTextNormal.alignment = "MiddleCenter"
		v471.creditsTextNormal.wordWrap = false
		v471.creditsTextNormal.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.creditsTextHover = GUI.NewStyle()
		v471.creditsTextHover.alignment = "MiddleCenter"
		v471.creditsTextHover.wordWrap = false
		v471.creditsTextHover.normalTextColor = Vector4.New(1, 0, 0, 1)
		v471.menuBtnTextNormal = GUI.NewStyle()
		v471.menuBtnTextNormal.alignment = "MiddleLeft"
		v471.menuBtnTextNormal.wordWrap = false
		v471.menuBtnTextNormal.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.menuBtnTextPressed = GUI.NewStyle()
		v471.menuBtnTextPressed.alignment = "MiddleLeft"
		v471.menuBtnTextPressed.wordWrap = false
		v471.menuBtnTextPressed.normalTextColor = Vector4.New(215 / 255, 215 / 255, 215 / 255, 1)
		v471.playerListTextNormal = GUI.NewStyle()
		v471.playerListTextNormal.alignment = "MiddleCenter"
		v471.playerListTextNormal.wordWrap = false
		v471.playerListTextNormal.normalTextColor = Vector4.New(1, 1, 1, 1)
		v471.playerListTextPressed = GUI.NewStyle()
		v471.playerListTextPressed.alignment = "MiddleCenter"
		v471.playerListTextPressed.wordWrap = false
		v471.playerListTextPressed.normalTextColor = Vector4.New(215 / 255, 215 / 255, 215 / 255, 1)
		v471.colorItemSty = GUI.NewStyle()
		v471.colorItemSty.alignment = "MiddleCenter"
		if Importer and Importer.ImportTexture then
			local v369 = File.GetModRoot()
			v193 = Importer.ImportTexture(v369 .. "/Icons/QQ.png")
			v133 = Importer.ImportTexture(v369 .. "/Icons/servers.png")
			v70 = Importer.ImportTexture(v369 .. "/Icons/publish.png")
			v58 = Importer.ImportTexture(v369 .. "/Icons/telegram.png")
			v1 = Importer.ImportTexture(v369 .. "/Icons/discord.png")
			v471.reloadTex = Importer.ImportTexture(v369 .. "/Icons/reload.png")
			v471.profileTex = Importer.ImportTexture(v369 .. "/Icons/Profile.png")
			v471.mpModTex = Importer.ImportTexture(v369 .. "/Icons/PUN.png")
			v471.hostTex = Importer.ImportTexture(v369 .. "/Icons/host.png")
			v471.mapIconTex = Importer.ImportTexture(v369 .. "/Icons/map.png")
			v471.kickTex = Importer.ImportTexture(v369 .. "/Icons/kick.png")
			v471.playersTabTex = Importer.ImportTexture(v369 .. "/Icons/Players.png")
			v471.gamemodeTabTex = Importer.ImportTexture(v369 .. "/Icons/Gamemode Editor.png")
			v471.showTetoOverlay = (File.GetPlayerPrefsStr("showTetoOverlay", "false") == "true")
			v471.tetoTex = Importer.ImportTexture(v369 .. "/Icons/mygirl.png")
			v471.flagTexs = {}
			local v145 = {
				"eu",
				"sa",
				"us",
				"ru",
				"in",
				"au",
				"jp",
				"tr",
				"asia"
			}
			for v531 = 1, # v145 do
				v471.flagTexs[v145[v531]] = Importer.ImportTexture(File.GetModRoot() .. "/flags/" .. v145[v531] .. ".png")
			end
		end
		v623(v171)
		v623(v471.solidStyle)
		v623(v568)
		v623(v634)
		v623(v471.btnHoverBg)
		v623(v471.btnHoverNoBg)
		v623(v471.btnNormalBg)
		v623(v471.btnNormalNoBg)
		v623(v471.btnGreenBg)
		v623(v471.btnGreenNoBg)
		v623(v471.placeholderStyle)
		v623(v471.tStyTitle)
		v623(v471.tStyDesc)
		v623(v471.tStyMap)
		v623(v471.joinBg)
		v623(v471.joinTStyNormal)
		v623(v471.joinTStyHover)
		v623(v471.nStyTitle)
		v623(v471.nStyDesc)
		v623(v471.socialBtnSty)
		v623(v471.socialTextNormal)
		v623(v471.socialTextHover)
		v623(v471.creditsTextNormal)
		v623(v471.creditsTextHover)
		v623(v471.menuBtnTextNormal)
		v623(v471.menuBtnTextPressed)
		v623(v471.playerListTextNormal)
		v623(v471.playerListTextPressed)
		v623(v471.colorItemSty)
		v590 = true
	end
	local v609 = Input.GetMousePosition()
	local v336 = v150 - v609.y
	local function v306(baseRect, defaultColor, noBg)
		local v631 = v609.x >= baseRect.x and v609.x <= baseRect.x + baseRect.z and v336 >= baseRect.y and v336 <= baseRect.y + baseRect.w
		if v631 then
			return noBg and v471.btnHoverNoBg or v471.btnHoverBg
		else
			if defaultColor and defaultColor.x == 0.2 and defaultColor.y == 1 and defaultColor.z == 0.2 then
				return noBg and v471.btnGreenNoBg or v471.btnGreenBg
			else
				return noBg and v471.btnNormalNoBg or v471.btnNormalBg
			end
		end
	end
	local function v497(r, t, v167)
		GUI.SetColor(v167)
		GUI.Box(Vector4.New(r.x, r.y, r.z, t), "", v471.solidStyle)
		GUI.Box(Vector4.New(r.x, r.y + r.w - t, r.z, t), "", v471.solidStyle)
		GUI.Box(Vector4.New(r.x, r.y, t, r.w), "", v471.solidStyle)
		GUI.Box(Vector4.New(r.x + r.z - t, r.y, t, r.w), "", v471.solidStyle)
		GUI.ResetColors()
	end
	if v337 then
		local v366 = v507
		local v223 = v595
		local v651 = 0 + v86
		local v491 = (v654 - v651) / 2 + v637
		local v483 = (v150 - v366) / 2 + v673
		local v169 = v662(5)
		local v317 = Vector4.New(31 / 255, 27 / 255, 27 / 255, 1.0)
		local v496 = Vector4.New(0, 0, 0, 0.8)
		local v27 = v491 - v55 - v223 + v271
		local v515 = v483 + v620
		local v399 = Vector4.New(v27, v515, v55, v523)
		GUI.SetColor(v496)
		GUI.Box(v399, "", v471.solidStyle)
		GUI.SetColor(v317)
		GUI.Box(Vector4.New(v399.x, v399.y, v399.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v399.x, v399.y + v399.w - v169, v399.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v399.x, v399.y, v169, v399.w), "", v471.solidStyle)
		GUI.Box(Vector4.New(v399.x + v399.z - v169, v399.y, v169, v399.w), "", v471.solidStyle)
		GUI.ResetColors()
		GUI.BeginArea(v399)
		local v286 = v662(20)
		local v134 = v662(38)
		local v50 = v662(48)
		local v378 = v662(75)
		local v506 = v662(80)
		GUI.LabelRect(Vector4.New(v662(20), v286 + v608, v55 - v662(40), v662(25)), "<size=" .. v180(22) .. ">社区</size>", v568)
		v286 = v286 + v662(40)
		v471.addComName = v471.addComName or ""
		v471.addComApp = v471.addComApp or ""
		v471.addComVoice = v471.addComVoice or ""
		local v418 = v654 < 1280
		local v322 = v418 and v662(120) or v662(80)
		local v458 = v418 and v662(140) or v662(100)
		local v602 = v418 and v662(160) or v662(120)
		GUI.LabelRect(Vector4.New(v662(20), v286 + (v134 - v662(25)) / 2 + v608, v322, v662(25)), "<size=" .. v180(18) .. ">名称</size>", v568)
		local v449 = Vector4.New(v458, v286, v55 - v602, v134)
		GUI.BeginArea(Vector4.New(v449.x, v449.y - v662(2), v449.z, v449.w + v662(4)))
		v471.addComName = GUI.TextField(v471.addComName, 64, v449.z, v449.w, v634)
		GUI.EndArea()
		v497(v449, v662(2), v317)
		v286 = v286 + v50
		GUI.LabelRect(Vector4.New(v662(20), v286 + (v134 - v662(25)) / 2 + v608, v322, v662(25)), "<size=" .. v180(18) .. ">应用ID</size>", v568)
		local v140 = Vector4.New(v458, v286, v55 - v602, v134)
		GUI.BeginArea(Vector4.New(v140.x, v140.y - v662(2), v140.z, v140.w + v662(4)))
		v471.addComApp = GUI.TextField(v471.addComApp, 64, v140.z, v140.w, v634)
		GUI.EndArea()
		v497(v140, v662(2), v317)
		v286 = v286 + v50
		GUI.LabelRect(Vector4.New(v662(20), v286 + (v134 - v662(25)) / 2 + v608, v322, v662(25)), "<size=" .. v180(18) .. ">语音ID</size>", v568)
		local v426 = Vector4.New(v458, v286, v55 - v602, v134)
		GUI.BeginArea(Vector4.New(v426.x, v426.y - v662(2), v426.z, v426.w + v662(4)))
		v471.addComVoice = GUI.TextField(v471.addComVoice, 64, v426.z, v426.w, v634)
		GUI.EndArea()
		v497(v426, v662(2), v317)
		v286 = v286 + v662(50)
		if v412 then
			local v343 = Vector4.New(v662(20), v286, v55 - v662(40), v662(38))
			local v516 = Vector4.New(v399.x + v662(20), v399.y + v286, v55 - v662(40), v662(38))
			local v339 = GUI.ButtonRect(v343, "<size=" .. v180(18) .. ">+ 添加社区</size>", v306(v516))
			v497(v343, v662(2), v317)
			if v339 then
				table.insert(v627, {
					v471.addComName,
					v471.addComApp,
					v471.addComVoice
				})
				v266()
				v471.addComName = ""
				v471.addComApp = ""
				v471.addComVoice = ""
			end
			v286 = v286 + v662(50)
		end
		GUI.LabelRect(Vector4.New(v662(20), v286 + v608, v55 - v662(40), v662(20)), "<size=" .. v180(16) .. "><color=#777>已保存的社区</color></size>", v568)
		v286 = v286 + v662(25)
		v471.comsScroll = v471.comsScroll or Vector2.New(0, 0)
		local v65 = Input.GetAxis("Mouse ScrollWheel")
		local v205 = v523 - v286 - v662(10)
		if v65 and v65 ~= 0 then
			if v609.x >= v399.x and v609.x <= v399.x + v55 and v336 >= v399.y + v286 and v336 <= v399.y + v286 + v205 then
				v471.comsScroll.y = math.max(0, v471.comsScroll.y - v65 * v662(100))
			end
		end
		GUI.BeginArea(Vector4.New(0, v286, v55, v205))
		v471.comsScroll = GUI.BeginScrollView(v471.comsScroll, v55 - v662(20), v205)
		GUI.Space(v188 * v506)
		for v531 = v188, 1, - 1 do
			local v545 = v627[v531]
			if v545 then
				local v539 = (v613 == v545[1])
				local v298 = (v188 - v531) * v506
				local v108 = v55 - v662(75)
				local v259 = Vector4.New(v662(10), v298, v108, v378)
				local v76 = Vector4.New(v399.x + v662(10), v399.y + v286 + v298 - v471.comsScroll.y, v108, v378)
				local v12 = v609.x >= v76.x and v609.x <= v76.x + v76.z and v336 >= v76.y and v336 <= v76.y + v76.w
				local v496 = Vector4.New(0.05, 0.05, 0.05, 0.9)
				if v539 then
					v496 = Vector4.New(0.3, 0.3, 0.3, 0.9)
				elseif v12 then
					v496 = Vector4.New(0.15, 0.15, 0.15, 0.9)
				end
				GUI.SetColor(v496)
				GUI.Box(v259, "", v471.solidStyle)
				GUI.ResetColors()
				v497(v259, v662(1), v317)
				if GUI.ButtonRect(v259, "", v471.btnNormalNoBg) then
					v613 = v545[1]
					v276 = v545[2]
					v437 = v545[3]
					v68()
					v448()
				end
				local v175 = v539 and "► " or ""
				local v629 = v12 and "#ff4444" or (v539 and "#55ff55" or "#ffffff")
				local v567 = v12 and "#ff8888" or "#888888"
				GUI.LabelRect(Vector4.New(v662(20), v298 + v662(12) + v608, v108 - v662(40), v662(25)), "<size=" .. v180(16) .. "><color=" .. v629 .. ">" .. v175 .. v545[1] .. "</color></size>", v471.nStyTitle)
				GUI.LabelRect(Vector4.New(v662(20), v298 + v662(38) + v608, v108 - v662(40), v662(25)), "<size=" .. v180(12) .. "><color=" .. v567 .. ">" .. v545[2] .. "</color></size>", v471.nStyTitle)
				local v484 = Vector4.New(v662(10) + v108 + v662(5), v298, v662(35), v378)
				local v674 = Vector4.New(v399.x + v662(10) + v108 + v662(5), v399.y + v286 + v298 - v471.comsScroll.y, v662(35), v378)
				local v24 = v609.x >= v674.x and v609.x <= v674.x + v674.z and v336 >= v674.y and v336 <= v674.y + v674.w
				local v493 = v24 and Vector4.New(0.15, 0.15, 0.15, 0.9) or Vector4.New(0.05, 0.05, 0.05, 0.9)
				GUI.SetColor(v493)
				GUI.Box(v484, "", v471.solidStyle)
				GUI.ResetColors()
				v497(v484, v662(1), v317)
				if GUI.ButtonRect(v484, "", v471.btnNormalNoBg) then
					v471.comToDelete = v531
				end
				local v281 = v24 and "#ffaaaa" or "#ff4444"
				GUI.LabelRect(Vector4.New(v484.x, v484.y + (v378 - v662(55)) / 2 + v608, v484.z, v662(55)), "<size=" .. v180(18) .. "><color=" .. v281 .. "><align=center>X</align></color></size>", v471.btnNormalNoBg)
			end
		end
		GUI.EndScrollView()
		GUI.EndArea()
		GUI.EndArea()
		if v471.comToDelete then
			table.remove(v627, v471.comToDelete)
			v266()
			v471.comToDelete = nil
		end
		local v194 = v491
		local v364 = v194 + 0
		local v611 = Vector4.New(v364, v483, v86, v366 - v662(145))
		GUI.SetColor(v496)
		GUI.Box(v611, "", v471.solidStyle)
		GUI.SetColor(v317)
		GUI.Box(Vector4.New(v611.x, v611.y, v611.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v611.x, v611.y + v611.w - v169, v611.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v611.x, v611.y, v169, v611.w), "", v471.solidStyle)
		GUI.Box(Vector4.New(v611.x + v611.z - v169, v611.y, v169, v611.w), "", v471.solidStyle)
		GUI.ResetColors()
		GUI.BeginArea(v611)
		local v440 = v662(20)
		local v508 = v418 and v662(160) or v662(120)
		local v17 = v418 and v662(180) or v662(140)
		local v395 = v418 and v662(200) or v662(160)
		local v661 = v662(38)
		local v293 = v662(48)
		GUI.LabelRect(Vector4.New(v662(20), v440 + (v661 - v662(25)) / 2 + v608, v508, v662(25)), "<size=" .. v180(18) .. ">房间名</size>", v568)
		local v564 = Vector4.New(v17, v440, v86 - v395, v661)
		GUI.BeginArea(Vector4.New(v564.x, v564.y - v662(2), v564.z, v564.w + v662(4)))
		local v256 = GUI.TextField(v25, 32, v564.z, v564.w, v634)
		GUI.EndArea()
		v497(v564, v662(2), v317)
		if v256 ~= v25 then
			v25 = v256
			v68()
		end
		v440 = v440 + v293
		GUI.LabelRect(Vector4.New(v662(20), v440 + (v661 - v662(25)) / 2 + v608, v508, v662(25)), "<size=" .. v180(18) .. ">区域</size>", v568)
		local v54 = Vector4.New(v17, v440, v86 - v395, v661)
		local v20 = Vector4.New(v611.x + v17, v611.y + v440, v86 - v395, v661)
		local v541 = GUI.ButtonRect(v54, "<size=" .. v180(18) .. ">" .. (v302 and "▼ " or "▶ ") .. v348 .. "</size>", v306(v20))
		v497(v54, v662(2), v317)
		if v541 then
			v402 = not v402
			if v402 then
				v297 = false
			end
		end
		v440 = v440 + v293
		local v221 = 0
		if v302 then
			local v159 = v86 - v395
			local v527 = Vector4.New(v17, v440, v159, v662(105))
			GUI.SetColor(v496)
			GUI.Box(v527, "", v471.solidStyle)
			GUI.ResetColors()
			local v18 = Input.GetAxis("Mouse ScrollWheel")
			if v18 and v18 ~= 0 then
				if v609.x >= v611.x + v17 and v609.x <= v611.x + v17 + v159 and v336 >= v611.y + v440 and v336 <= v611.y + v440 + v662(105) then
					v416.y = math.max(0, v416.y - v18 * v662(100))
				end
			end
			GUI.BeginArea(v527)
			v416 = GUI.BeginScrollView(v416, v159, v662(105))
			GUI.Space(# v10 * v662(30))
			for v531 = 1, # v10 do
				local v537 = v10[v531]
				local v226 = (v531 - 1) * v662(30)
				local v182 = Vector4.New(0, v226, v159 - v662(20), v662(30))
				local v2 = Vector4.New(v611.x + v17, v611.y + v440 + v226 - v416.y, v159 - v662(20), v662(30))
				local v12 = v609.x >= v2.x and v609.x <= v2.x + v2.z and v336 >= v2.y and v336 <= v2.y + v2.w
				local v401 = Vector4.New(1, 1, 1, 1)
				local v269 = v306(v2, v401, true)
				local v530 = v12 and Vector4.New(0.15, 0.15, 0.15, 0.95) or Vector4.New(0.05, 0.05, 0.05, 0.95)
				GUI.SetColor(v530)
				GUI.Box(v182, "", v471.solidStyle)
				GUI.ResetColors()
				v497(v182, v662(1), v317)
				local v644 = GUI.ButtonRect(v182, "", v269)
				local v51 = v662(10)
				local v258 = v471.flagTexs and v471.flagTexs[v537]
				if v258 and v258.IsValid() then
					GUI.SetColor(Vector4.New(1, 1, 1, 1))
					GUI.DrawTexture(Vector4.New(v51, v226 + v662(6) + v608, v662(23), v662(18)), v258, "StretchToFill", true, 1)
					v51 = v51 + v662(36)
					GUI.ResetColors()
				end
				GUI.LabelRect(Vector4.New(v51, v226 + v662(2) + v608, v182.z - v51, v662(25)), "<size=" .. v180(18) .. ">" .. v15[v537] .. "</size>", v568)
				if v644 then
					v535 = v537
					v348 = v15[v535]
					v402 = false
					v68()
				end
			end
			GUI.EndScrollView()
			GUI.EndArea()
			v497(v527, v662(2), v317)
			v221 = v662(105)
		end
		local v390 = v440 + v221
		GUI.LabelRect(Vector4.New(v662(20), v390 + (v661 - v662(25)) / 2 + v608, v508, v662(25)), "<size=" .. v180(18) .. ">地图</size>", v568)
		local v488 = Vector4.New(v17, v390, v86 - v395, v661)
		local v374 = Vector4.New(v611.x + v17, v611.y + v390, v86 - v395, v661)
		local v578 = GUI.ButtonRect(v488, "<size=" .. v180(18) .. ">" .. (v522 and "▼ " or "▶ ") .. (v340_display[v550] or v550) .. "</size>", v306(v374))
		v497(v488, v662(2), v317)
		if v578 then
			v297 = not v297
			if v297 then
				v402 = false
			end
		end
		local v665 = v390 + v293
		if v522 then
			local v159 = v86 - v395
			local v527 = Vector4.New(v17, v665, v159, v662(105))
			GUI.SetColor(v496)
			GUI.Box(v527, "", v471.solidStyle)
			GUI.ResetColors()
			local v75 = Input.GetAxis("Mouse ScrollWheel")
			if v75 and v75 ~= 0 then
				if v609.x >= v611.x + v17 and v609.x <= v611.x + v17 + v159 and v336 >= v611.y + v665 and v336 <= v611.y + v665 + v662(105) then
					v382.y = math.max(0, v382.y - v75 * v662(100))
				end
			end
			GUI.BeginArea(v527)
			v382 = GUI.BeginScrollView(v382, v159, v662(105))
			local v146 = {}
			for v393, v in tableIterators.pairs(v340) do
				table.insert(v146, v393)
			end
			GUI.Space(# v146 * v662(30))
			for v531 = 1, # v146 do
				local v218 = v146[v531]
				local v226 = (v531 - 1) * v662(30)
				local v182 = Vector4.New(0, v226, v159 - v662(20), v662(30))
				local v2 = Vector4.New(v611.x + v17, v611.y + v665 + v226 - v382.y, v159 - v662(20), v662(30))
				local v12 = v609.x >= v2.x and v609.x <= v2.x + v2.z and v336 >= v2.y and v336 <= v2.y + v2.w
				local v401 = Vector4.New(1, 1, 1, 1)
				local v269 = v306(v2, v401, true)
				local v530 = v12 and Vector4.New(0.15, 0.15, 0.15, 0.95) or Vector4.New(0.05, 0.05, 0.05, 0.95)
				GUI.SetColor(v530)
				GUI.Box(v182, "", v471.solidStyle)
				GUI.ResetColors()
				v497(v182, v662(1), v317)
				local v383 = GUI.ButtonRect(v182, "", v269)
				local v51 = v662(12)
				if v471.mapIconTex and v471.mapIconTex.IsValid() then
					GUI.SetColor(Vector4.New(1, 1, 1, 1))
					GUI.DrawTexture(Vector4.New(v51, v226 + v662(6) + v608, v662(18), v662(18)), v471.mapIconTex, "ScaleToFit", true, 0)
					v51 = v51 + v662(31)
					GUI.ResetColors()
				end
				GUI.LabelRect(Vector4.New(v51, v226 + v662(2) + v608, v182.z - v51, v662(25)), "<size=" .. v180(18) .. ">" .. (v340_display[v218] or v218) .. "</size>", v568)
				if v383 then
					v550 = v218
					v297 = false
					v68()
				end
			end
			GUI.EndScrollView()
			GUI.EndArea()
			v497(v527, v662(2), v317)
			v665 = v665 + v662(105)
		end
		local v390 = v440 + v221
		GUI.LabelRect(Vector4.New(v662(20), v390 + (v661 - v662(25)) / 2 + v608, v508, v662(25)), "<size=" .. v180(18) .. ">地图</size>", v568)
		local v488 = Vector4.New(v17, v390, v86 - v395, v661)
		local v374 = Vector4.New(v611.x + v17, v611.y + v390, v86 - v395, v661)
		local v578 = GUI.ButtonRect(v488, "<size=" .. v180(18) .. ">" .. (v522 and "▼ " or "▶ ") .. (v340_display[v550] or v550) .. "</size>", v306(v374))
		v497(v488, v662(2), v317)
		if v578 then
			v297 = not v297
			if v297 then
				v402 = false
			end
		end
		v665 = v665 + v662(10)
		GUI.LabelRect(Vector4.New(v662(20), v665 + v608, v86 - v662(40), v662(25)), "<size=" .. v180(20) .. ">高级选项：</size>", v568)
		v665 = v665 + v662(35)
		local function v466(rect, label, v164)
			local v199 = Vector4.New(v611.x + rect.x, v611.y + rect.y, rect.z, rect.w)
			local v12 = v609.x >= v199.x and v609.x <= v199.x + v199.z and v336 >= v199.y and v336 <= v199.y + v199.w
			local v489 = v12 and "#ff5555" or (v164 and "#55ff55" or "#ffffff")
			local v377 = v164 and "☑ " or "☐ "
			local v14 = "<size=" .. v180(18) .. "><color=" .. v489 .. ">" .. v377 .. "</color>" .. label .. "</size>"
			local v33 = GUI.NewStyle()
			v33.normalTextColor = Vector4.New(1, 1, 1, 1)
			v33.alignment = "MiddleLeft"
			if GUI.ButtonRect(rect, v14, v33) then
				v385 = 0
				v22 = 0
				return not v164
			end
			return v164
		end
		local v667 = v662(20)
		local v648 = v662(320)
		local v492 = v662(250)
		local v423 = v662(32)
		v573 = v466(Vector4.New(v667, v665, v492, v423), "启用GBRP", v573)
		v650 = v466(Vector4.New(v648, v665, v492, v423), "空中控制", v650)
		v451 = v650
		v665 = v665 + v662(36)
		v114 = v466(Vector4.New(v667, v665, v492, v423), "禁止交互", v114)
		v137 = v114
		v91 = v466(Vector4.New(v648, v665, v492, v423), "锁定状态", v91)
		v502 = v91
		v665 = v665 + v662(36)
		v36 = v466(Vector4.New(v667, v665, v492, v423), "禁止连跳", v36)
		v176 = v36
		v406 = v466(Vector4.New(v648, v665, v492, v423), "允许帽子", v406)
		v103 = v406
		v665 = v665 + v662(45)
		local v11 = Vector4.New(v662(20), v665, v86 - v662(40), v662(45))
		local v72 = Vector4.New(v611.x + v662(20), v611.y + v665, v86 - v662(40), v662(40))
		local v155 = GUI.ButtonRect(v11, "<size=" .. v180(20) .. ">" .. (v147 and "<color=#8f8><b>正在加入 " or "<b>连接并加入 ") .. v25 .. "</size>", v306(v72))
		v497(v11, v662(2), v317)
		if v155 then
			if v276 == "" then
				v477 = "<color=#ff4444>请先选择一个社区</color>"
				v186 = v105
			elseif not v147 then
				v290()
			end
		end
		GUI.EndArea()
		local v460 = v662(270)
		local v236 = Vector4.New(v364, v483 + v366 - v662(150), v86, v460)
		GUI.SetColor(v496)
		GUI.Box(v236, "", v471.solidStyle)
		GUI.SetColor(v317)
		GUI.Box(Vector4.New(v236.x, v236.y, v236.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v236.x, v236.y + v236.w - v169, v236.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v236.x, v236.y, v169, v236.w), "", v471.solidStyle)
		GUI.Box(Vector4.New(v236.x + v236.z - v169, v236.y, v169, v236.w), "", v471.solidStyle)
		GUI.ResetColors()
		GUI.BeginArea(v236)
		local v40 = basicModule.tostring(v164)
		local v455 = string.lower(v40)
		local v310 = "#ff5555"
		if string.find(v455, "disconnect") then
			v310 = "#ff5555"
		elseif string.find(v455, "joined") and not string.find(v455, "lobby") then
			v310 = "#55ff55"
		elseif string.find(v455, "connect") or string.find(v455, "lobby") then
			v310 = "#ffaa00"
		end
		local v628 = "#55ff55"
		local v326 = basicModule.tonumber(v64) or 0
		if v326 > 150 then
			v628 = "#ff5555"
		elseif v326 > 80 then
			v628 = "#ffff55"
		end
		GUI.LabelRect(Vector4.New(v662(20), v662(10) + v608, v86 - v662(40), v662(20)), "<size=" .. v180(20) .. "><align=center><color=#ffffff>服务器状态</color></align></size>", v568)
		local v101 = v471.IKCode or basicModule.tostring(v106) or "Unknown"
		if v654 < 1280 then
			local v486 = string.format("<size=9px><color=#aaaaaa>状态：</color> <color=%s>%s</color> | <color=#aaaaaa>IP：</color> <color=#55ffff>[%s]</color> | <color=#aaaaaa>延迟：</color> <color=%s>%sms</color></size>", v310, v40, v447, v628, v64)
			local v37 = string.format("<size=9px><color=#aaaaaa>匹配码：</color> <color=#baffba><b>%s</b></color></size>", v101)
			GUI.LabelRect(Vector4.New(v662(20), v662(35) + v608, v86 - v662(40), v662(20)), v486, v568)
			GUI.LabelRect(Vector4.New(v662(20), v662(55) + v608, v86 - v662(40), v662(20)), v37, v568)
			v471.jCodeRelActual = Vector4.New(v662(20), v662(80), v86 - v662(40), v662(125))
		else
			local v486 = string.format("<size=%d><color=#aaaaaa>状态：</color> <color=%s>%s</color> | <color=#aaaaaa>IP：</color> <color=#55ffff>[%s]</color> | <color=#aaaaaa>延迟：</color> <color=%s>%sms</color> | <color=#aaaaaa>匹配码：</color> <color=#baffba><b>%s</b></color></size>", v180(18), v310, v40, v447, v628, v64, v101)
			GUI.LabelRect(Vector4.New(v662(20), v662(35) + v608, v86 - v662(40), v662(20)), v486, v568)
			v471.jCodeRelActual = Vector4.New(v662(20), v662(60), v86 - v662(40), v662(125))
		end
		local v99 = v471.jCodeRelActual
		GUI.BeginArea(Vector4.New(v99.x, v99.y - v662(2), v99.z, v99.w + v662(4)))
		local v292 = GUI.NewStyle()
		v292.background = v634.background
		v292.normalTextColor = v634.normalTextColor
		v292.alignment = "UpperLeft"
		v292.padding = Vector4.New(math.floor(v662(math.floor(303 - 299))), math.floor(v662(math.floor(8812 - 8808))), math.floor(v662(- math.floor(949 - 945))), 0)
		v292.margin = v634.margin
		v292.wordWrap = true
		local v303 = "<size=" .. v180(14) .. ">" .. v222 .. "</size>"
		local v603 = GUI.TextArea(v303, 1024, v99.z, v99.w, v292)
		if v603 then
			v603 = string.gsub(v603, "<size=%d+>", "")
			v603 = string.gsub(v603, "</size>", "")
		end
		GUI.EndArea()
		v497(v99, v662(2), v317)
		if v603 ~= v222 then
			v222 = v603
			v442(v222)
		end
		if v357 then
			GUI.LabelRect(Vector4.New(v662(20), v662(192) + v608, v86 - v662(40), v662(25)), "<size=" .. v180(18) .. ">" .. v477 .. "</size>", v568)
		end
		GUI.EndArea()
	elseif v203 then
		local v651 = v662(1920)
		local v439 = v662(750)
		local v491 = (v654 - v651) / 2 + v662(0)
		local v483 = (v150 - v439) / 2 + v662(- 4)
		local v169 = v662(5)
		local v317 = Vector4.New(31 / 255, 27 / 255, 27 / 255, 1.0)
		local v496 = Vector4.New(0, 0, 0, 0.9)
		local v461 = Vector4.New(v491, v483, v651, v439)
		GUI.SetColor(v496)
		GUI.Box(v461, "", v471.solidStyle)
		GUI.SetColor(v317)
		GUI.Box(Vector4.New(v461.x, v461.y, v461.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v461.x, v461.y + v461.w - v169, v461.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v461.x, v461.y, v169, v461.w), "", v471.solidStyle)
		GUI.Box(Vector4.New(v461.x + v461.z - v169, v461.y, v169, v461.w), "", v471.solidStyle)
		GUI.ResetColors()
		local v419 = v651 * 0.65
		local v85 = v651 * 0.35
		GUI.SetColor(v317)
		GUI.Box(Vector4.New(v461.x + v419, v461.y, v169, v461.w), "", v471.solidStyle)
		GUI.ResetColors()
		GUI.BeginArea(v461)
		local v605 = v662(35)
		local v462 = v662(45)
		local v309 = v419 - v462 - v662(32)
		local v504 = Vector4.New(v461.x + v662(10), v461.y + v662(15), v462, v605)
		local v224 = v306(v504, Vector4.New(1, 1, 1, 1), true)
		local v19 = Vector4.New(v662(10), v662(15), v462, v605)
		GUI.SetColor(Vector4.New(0.05, 0.05, 0.05, 0.95))
		GUI.Box(v19, "", v471.solidStyle)
		GUI.ResetColors()
		local v668 = GUI.ButtonRect(v19, "", v224)
		v497(v19, v662(2), v317)
		if v668 then
			if v584 then
				v584()
			end
		end
		if v471.reloadTex and v471.reloadTex.IsValid() then
			local v617 = v609.x >= v504.x and v609.x <= v504.x + v504.z and v336 >= v504.y and v336 <= v504.y + v504.w
			GUI.SetColor(Vector4.New(1, 1, 1, v617 and 0.7 or 1))
			GUI.DrawTexture(Vector4.New(v662(10) + (v462 - v662(24)) / 2, v662(15) + (v605 - v662(24)) / 2, v662(24), v662(24)), v471.reloadTex, "StretchToFill", true, 1)
			GUI.ResetColors()
		end
		local v663 = v662(10) + v462 + v662(10)
		local v338 = Vector4.New(v663, v662(15), v309, v605)
		GUI.BeginArea(Vector4.New(v338.x, v338.y - v662(2), v338.z, v338.w + v662(4)))
		v471.srvSearch = GUI.TextField(v471.srvSearch, 64, v338.z, v338.w, v634)
		GUI.EndArea()
		v497(v338, v662(2), v317)
		if v471.srvSearch == "" then
			GUI.LabelRect(Vector4.New(v663 + v662(5), v662(15) + v608, v309, v605), "<size=" .. v180(18) .. ">搜索服务器...</size>", v471.placeholderStyle)
		end
		v471.filteredServersCache = v471.filteredServersCache or {}
		local v513 = false
		if v471.cachedSearchStr ~= v471.srvSearch then
			v471.cachedSearchStr = v471.srvSearch
			v513 = true
		end
		if v471.lastWebServers ~= v471.webServers then
			v471.lastWebServers = v471.webServers
			v513 = true
		end
		if v513 then
			v471.filteredServersCache = {}
			local v66 = string.lower(v471.srvSearch or "")
			local v346 = # (v471.webServers or {})
			for v531 = 1, v346 do
				local v427 = v471.webServers[v531]
				if v427 and v427.isDeleted ~= true then
					local v152 = basicModule.tostring(v427.name)
					local v240 = string.lower(v370(v152, true))
					if v66 == "" or string.find(v240, v66, 1, true) then
						local v49 = v370(basicModule.tostring(v427.name), false)
						local v341 = basicModule.tostring(v427.map or "Unknown")
						local v92 = basicModule.tostring(v427.id or "")
						local v586 = string.lower(basicModule.tostring(v427.country or "eu"))
						local v177 = basicModule.tostring(v427.description or "")
						local v111 = v370(v177, false)
						v111 = string.gsub(v111, "\r", "")
						local v551 = string.match(v111, "^([^\n]+)") or v111
						local v501 = v202(v551, 45)
						table.insert(v471.filteredServersCache, {
							raw = v427,
							v365 = v49,
							map = v341,
							id = v92,
							desc = v501,
							region = v586
						})
					end
				end
			end
		end
		local v141 = # v471.filteredServersCache
		local v418 = v654 < 1280
		local v598 = v418 and v662(110) or v662(85)
		local v392 = v662(5)
		local v179 = v598 + v392
		local v282 = v439 - v662(75)
		local v331 = v141 * v179
		local v109 = math.max(0, v331 - v282)
		local v443 = Input.GetAxis("Mouse ScrollWheel")
		if v443 and v443 ~= 0 then
			if v609.x >= v461.x and v609.x <= v461.x + v419 and v336 >= v461.y + v662(60) and v336 <= v461.y + v662(60) + v282 then
				v471.serverListScrollPos.y = math.max(0, math.min(v109, v471.serverListScrollPos.y - v443 * v662(150)))
			end
		end
		local v232 = v419 - v662(10)
		if v446 then
			local v655 = v105 - (v471.fetchAnimStartTime or v105)
			local v622 = 0
			if v471.fetchAnimEnding then
				local v465 = v105 - (v471.fetchAnimEndTime or v105)
				v622 = 1 - math.min(1, v465 / 200)
			else
				v622 = math.min(1, v655 / 300)
			end
			local v5 = math.floor(v180(math.floor(9599 - 9479)) * v622)
			local v57 = v662(10) + v232 / 2
			local v345 = v662(60) + v282 / 2
			if v5 > 1 then
				local v165 = math.floor((v105 * 0.3) % 360)
				local v534 = "<rotate=" .. v165 .. ">🗖</rotate>"
				local v314 = GUI.NewStyle()
				v314.alignment = "MiddleCenter"
				v314.normalTextColor = Vector4.New(1, 1, 1, 1)
				local v318 = Vector4.New(v57 - v662(150), v345 - v662(150) + v662(- 18), v662(300), v662(300))
				GUI.LabelRect(v318, "<size=" .. v5 .. ">" .. v534 .. "</size>", v314)
			end
		elseif v141 == 0 then
			GUI.LabelRect(Vector4.New(v662(10), v662(60) + v608, v232 - v662(20), v662(30)), "<size=" .. v180(20) .. ">未找到服务器。</size>", v568)
		else
			GUI.BeginArea(Vector4.New(v662(10), v662(60), v232, v282))
			v471.serverListScrollPos = GUI.BeginScrollView(v471.serverListScrollPos, v232, v282)
			GUI.Space(v331)
			local v342 = math.floor(v471.serverListScrollPos.y / v179) + 1
			local v128 = math.ceil((v471.serverListScrollPos.y + v282) / v179)
			if v342 < 1 then
				v342 = 1
			end
			if v128 > v141 then
				v128 = v141
			end
			local v473 = (v109 > 0) and (v232 - v662(20)) or (v232 - v662(5))
			for v531 = v342, v128 do
				local v479 = v471.filteredServersCache[v531]
				local v572 = (v531 - 1) * v179
				local v516 = Vector4.New(v461.x + v662(10), v461.y + v662(60) + v572 - v471.serverListScrollPos.y, v473, v598)
				local v539 = (v376 and v376.id == v479.id)
				local v12 = v609.x >= v516.x and v609.x <= v516.x + v516.z and v336 >= v516.y and v336 <= v516.y + v516.w
				local v401 = Vector4.New(1, 1, 1, 1)
				local v269 = v306(v516, v401, true)
				local v343 = Vector4.New(0, v572, v473, v598)
				v497(v343, v662(1), v317)
				local v530
				if v539 then
					v530 = Vector4.New(0.2, 0.2, 0.2, 0.95)
				elseif v12 then
					v530 = Vector4.New(0.12, 0.12, 0.12, 0.95)
				else
					v530 = Vector4.New(0.05, 0.05, 0.05, 0.95)
				end
				GUI.SetColor(v530)
				GUI.Box(v343, "", v471.solidStyle)
				GUI.ResetColors()
				if GUI.ButtonRect(v343, "", v269) then
					v471.selectedServerInfo = v479.raw
				end
				local v51 = v662(10)
				local v258 = v471.flagTexs and v471.flagTexs[v479.region]
				if v258 and v258.IsValid() then
					GUI.SetColor(Vector4.New(1, 1, 1, 1))
					GUI.DrawTexture(Vector4.New(v51, v572 + v662(9) + v608, v662(23), v662(18)), v258, "StretchToFill", true, 1)
					v51 = v51 + v662(36)
					GUI.ResetColors()
				end
				GUI.LabelRect(Vector4.New(v51, v572 + v662(5) + v608, v473 - v51 - v662(10), v662(25)), "<size=" .. v180(20) .. "><b>" .. v479.name .. "</b></size>", v471.tStyTitle)
				local v43 = v418 and v662(38) or v662(30)
				local v621 = v418 and v662(40) or v662(20)
				local v390 = v418 and v662(78) or v662(55)
				GUI.LabelRect(Vector4.New(v662(10), v572 + v43 + v608, v473 - v662(20), v621), "<size=" .. v180(16) .. ">" .. v479.desc .. "</size>", v471.tStyDesc)
				GUI.LabelRect(Vector4.New(v662(10), v572 + v390 + v608, v473 - v662(20), v662(20)), "<size=" .. v180(16) .. "><b>地图：</b> " .. v479.map .. "</size>", v471.tStyMap)
			end
			GUI.EndScrollView()
			GUI.EndArea()
		end
		if v376 ~= nil then
			local v49 = v370(basicModule.tostring(v376.name))
			local v501 = v370(basicModule.tostring(v376.description or ""))
			GUI.LabelRect(Vector4.New(v419 + v662(15), v662(15) + v608, v85 - v662(30), v662(35)), "<size=" .. v180(22) .. "><b>" .. v49 .. "</b></size>", v471.nStyTitle)
			GUI.LabelRect(Vector4.New(v419 + v662(15), v662(60) + v608, v85 - v662(30), v439 - v662(200)), "<size=" .. v180(18) .. ">" .. v501 .. "</size>", v471.nStyDesc)
			local v587 = v439 - v662(120)
			local v367 = basicModule.tostring(v376.tg)
			local v672 = basicModule.tostring(v376.discord)
			local v512 = (v367 and v367 ~= "" and v367 ~= "nil")
			local v643 = (v672 and v672 ~= "" and v672 ~= "nil")
			local v638 = (v85 - v662(30))
			if v512 and v643 then
				v638 = (v85 - v662(35)) / 2
			end
			local v197 = v419 + v662(15)
			local v553 = v587
			local function v29(url, tex, btnColor, label, xOff, w)
				if not url or url == "" or url == "nil" then
					return xOff
				end
				local v248 = Vector4.New(v461.x + xOff, v461.y + v553, w, v662(40))
				local v631 = v609.x >= v248.x and v609.x <= v248.x + v248.z and v336 >= v248.y and v336 <= v248.y + v248.w
				local v157 = Vector4.New(xOff, v553, w, v662(40))
				v497(v157, v662(2), v317)
				GUI.SetColor(btnColor)
				if GUI.ButtonRect(v157, "", v471.socialBtnSty) then
					local v596 = GameObject.Create("linkOpener").AddComponent("BrowserLink")
					v596.SetField("url", url)
					v596.CallMethod("OpenLink")
					v596.GameObject.Destroy()
				end
				GUI.SetColor(Vector4.New(0.05, 0.05, 0.05, 0.95))
				GUI.Box(Vector4.New(v157.x + v662(2), v157.y + v662(2), v157.z - v662(4), v157.w - v662(4)), "", v471.solidStyle)
				GUI.ResetColors()
				GUI.SetColor(Vector4.New(1, 1, 1, 1))
				if tex and tex.IsValid() then
					GUI.DrawTexture(Vector4.New(v157.x + v662(10), v157.y + v662(8), v662(24), v662(24)), tex, "StretchToFill", true, 1)
				end
				GUI.LabelRect(Vector4.New(v157.x + v662(35), v157.y + v608, v157.z - v662(40), v157.w), "<size=" .. v180(18) .. "><b>" .. label .. "</b></size>", v631 and v471.socialTextHover or v471.socialTextNormal)
				return xOff + w + v662(5)
			end
			if v512 then
				v197 = v29(v367, v58, Vector4.New(40 / 255, 160 / 255, 220 / 255, 1), "Telegram", v197, v638)
			end
			if v643 then
				v197 = v29(v672, v1, Vector4.New(86 / 255, 98 / 255, 246 / 255, 1), "Discord", v197, v638)
			end
			local v514 = v553 + v662(50)
			local v601 = Vector4.New(v419 + v662(15), v514, v85 - v662(30), v662(45))
			local v344 = Vector4.New(v461.x + v419 + v662(15), v461.y + v514, v85 - v662(30), v662(45))
			local v563 = v609.x >= v344.x and v609.x <= v344.x + v344.z and v336 >= v344.y and v336 <= v344.y + v344.w
			GUI.SetColor(Vector4.New(0.05, 0.05, 0.05, 0.95))
			local v404 = GUI.ButtonRect(v601, "", v471.joinBg)
			GUI.ResetColors()
			v497(v601, v662(2), v317)
			local v626 = v147 and "<b>正在加入...</b>" or "<b>加入</b>"
			GUI.LabelRect(Vector4.New(v601.x, v601.y + v608, v601.z, v601.w), "<size=" .. v180(20) .. ">" .. v626 .. "</size>", v563 and v471.joinTStyHover or v471.joinTStyNormal)
			if v404 then
				local v110 = basicModule.tostring(v376.joinCode)
				if v110 and v110 ~= "nil" and v110 ~= "" then
					v442(v110)
					if not v147 then
						v290()
					end
				end
			end
			GUI.ResetColors()
		else
			GUI.LabelRect(Vector4.New(v419 + v662(15), v662(15) + v608, v85 - v662(30), v662(50)), "<size=" .. v180(18) .. "><color=#777>选择一个服务器查看详情</color></size>", v568)
		end
		GUI.EndArea()
	end
	if v200 and (v579 or v560 or v471.profileHidingCredits) then
		local v418 = v654 < 1280
		local v90 = v662(87)
		local v97 = v662(- 108)
		local v219 = v662(- 500)
		local v323 = v662(89)
		local v607 = v418 and v662(300) or v662(250)
		local v360 = v418 and v662(470) or v662(370)
		local v669 = v90
		local v529 = v662(25)
		local v614 = v662(5)
		local v524 = v607 + v360 + v529
		local v574 = v418 and v662(540) or v662(600)
		local v505 = (v654 - v524) / 2 - v574
		local v7 = v150 + v97
		GUI.BeginArea(Vector4.New(v505, v7, v524 + v662(50), v669 + v662(10)))
		GUI.SetColor(Vector4.New(0, 0, 0, 0.8))
		GUI.Box(Vector4.New(0, 0, v607, v669), "", v471.solidStyle)
		GUI.SetColor(Vector4.New(31 / 255, 27 / 255, 27 / 255, 1.0))
		GUI.Box(Vector4.New(0, 0, v607, v614), "", v471.solidStyle)
		GUI.Box(Vector4.New(0, v669 - v614, v607, v614), "", v471.solidStyle)
		GUI.Box(Vector4.New(0, 0, v614, v669), "", v471.solidStyle)
		GUI.Box(Vector4.New(v607 - v614, 0, v614, v669), "", v471.solidStyle)
		if v193 ~= nil and v193.IsValid() then
			GUI.SetColor(Vector4.New(1, 1, 1, 1))
			GUI.DrawTexture(Vector4.New(v662(30), (v669 - v662(58)) / 2, v662(64), v662(56)), v193, "StretchToFill", true, 1)
		end
		GUI.SetColor(Vector4.New(0, 0, 0, 0))
		if GUI.ButtonRect(Vector4.New(0, 0, v607, v669), "", v171) then
			local v596 = GameObject.Create("linkOpener").AddComponent("BrowserLink")
			v596.SetField("url", "https://qun.qq.com/universal-share/share?ac=1&authKey=RhIN0nHN5qn04rJoLM1pDRU%2F8zXK%2BUICBTrD35%2F2F4k5QbtCwTcdKGL02Kqctkjr&busi_data=eyJncm91cENvZGUiOiI5MTIyNTI0MDAiLCJ0b2tlbiI6Ikh1RHd3R2oxZGdsRVB6alVsMEc2OVp2YXA4SXVJZEFtQ3JSa2FFZExwTTZSRUdqWHBpbjZ1OFVXb0RONWZ2ZCsiLCJ1aW4iOiIxNTM2NjE4OTgzIn0%3D&data=ysypAG25my1eKGvbfqHaJ8h2XqxC3CERDL14iRDbFzs9wFXYv7ZmUhr1M_JCJp2WVhxDoepgo1Q1kN6ALKIZcQ&svctype=4&tempid=h5_group_info")
			v596.CallMethod("OpenLink")
			v596.GameObject.Destroy()
		end
		GUI.ResetColors()
		local v559 = v609.x >= v505 and v609.x <= v505 + v607 and v336 >= v7 and v336 <= v7 + v669
		local v251 = v418 and v662(120) or v662(100)
		local v172 = v418 and (v607 - v662(140)) or (v607 - v662(110))
		GUI.LabelRect(Vector4.New(v251, v608, v172, v669), "<size=" .. v180(24) .. ">Koilp的QQ群聊</size>", v559 and v471.creditsTextHover or v471.creditsTextNormal)
		if not v471.profileHidingCredits then
			local v330 = v607 + v529
			local v34 = v505 + v330
			GUI.SetColor(Vector4.New(0, 0, 0, 0.8))
			GUI.Box(Vector4.New(v330, 0, v360, v669), "", v471.solidStyle)
			GUI.SetColor(Vector4.New(31 / 255, 27 / 255, 27 / 255, 1.0))
			GUI.Box(Vector4.New(v330, 0, v360, v614), "", v471.solidStyle)
			GUI.Box(Vector4.New(v330, v669 - v614, v360, v614), "", v471.solidStyle)
			GUI.Box(Vector4.New(v330, 0, v614, v669), "", v471.solidStyle)
			GUI.Box(Vector4.New(v330 + v360 - v614, 0, v614, v669), "", v471.solidStyle)
			local v371 = v203 and v70 or v133
			local v494 = v203 and "发布服务器" or "社区服务器"
			if v371 ~= nil and v371.IsValid() then
				GUI.SetColor(Vector4.New(1, 1, 1, 1))
				GUI.DrawTexture(Vector4.New(v330 + v662(25), (v669 - v662(64)) / 2, v662(64), v662(64)), v371, "StretchToFill", true, 1)
			end
			GUI.SetColor(Vector4.New(0, 0, 0, 0))
			if GUI.ButtonRect(Vector4.New(v330, 0, v360, v669), "", v171) then
				if v549 then
					local v596 = GameObject.Create("linkOpener").AddComponent("BrowserLink")
					v596.SetField("url", "https://mpmod.vercel.app/")
					v596.CallMethod("OpenLink")
					v596.GameObject.Destroy()
				else
					v549 = true
					v560 = false
					v63 = false
					if v584 then
						v584()
					end
				end
			end
			GUI.ResetColors()
			local v291 = v609.x >= v34 and v609.x <= v34 + v360 and v336 >= v7 and v336 <= v7 + v669
			local v220 = v418 and v662(100) or v662(100)
			local v413 = v418 and (v360 - v220 - v662(10)) or (v360 - v662(110))
			GUI.LabelRect(Vector4.New(v330 + v220, v608, v413, v669), "<size=" .. v180(24) .. ">" .. v494 .. "</size>", v291 and v471.creditsTextHover or v471.creditsTextNormal)
		end
		GUI.EndArea()
		if not v471.profileHidingCredits then
			local v129 = v323
			local v480 = v90
			local v123 = v654 + v219
			local v577 = v7
			GUI.SetColor(Vector4.New(0, 0, 0, 0.8))
			GUI.Box(Vector4.New(v123, v577, v129, v480), "", v471.solidStyle)
			GUI.SetColor(Vector4.New(31 / 255, 27 / 255, 27 / 255, 1.0))
			GUI.Box(Vector4.New(v123, v577, v129, v614), "", v471.solidStyle)
			GUI.Box(Vector4.New(v123, v577 + v480 - v614, v129, v614), "", v471.solidStyle)
			GUI.Box(Vector4.New(v123, v577, v614, v480), "", v471.solidStyle)
			GUI.Box(Vector4.New(v123 + v129 - v614, v577, v614, v480), "", v471.solidStyle)
			local v35 = v609.x >= v123 and v609.x <= v123 + v129 and v336 >= v577 and v336 <= v577 + v480
			if v471.profileTex and v471.profileTex.IsValid() then
				if v35 then
					GUI.SetColor(Vector4.New(0.6, 0.6, 0.6, 1))
				else
					GUI.SetColor(Vector4.New(1, 1, 1, 1))
				end
				local v660 = v662(65)
				local v78 = v123 + (v323 - v660) / 2
				local v470 = v577 + (v90 - v660) / 2
				GUI.DrawTexture(Vector4.New(v78, v470, v660, v660), v471.profileTex, "StretchToFill", true, 1)
			end
			GUI.SetColor(Vector4.New(0, 0, 0, 0))
			GUI.ButtonRect(Vector4.New(v123, v577, v129, v480), "", v171)
			GUI.ResetColors()
			if v35 and not v471.profileHidingCredits then
				if v471.clonedCharBtn == nil or not v471.clonedCharBtn.IsValid() then
					local v474 = GameObject.FindByName("Menu/Socials/Char")
					if v474 ~= nil and v474.IsValid() then
						v471.clonedCharBtn = GameObject.Copy(v474)
						v471.clonedCharBtn.Name = "InvisibleCharClicker"
						for v531 = v471.clonedCharBtn.Transform.ChildCount - 1, 0, - 1 do
							v471.clonedCharBtn.Transform.GetChild(v531).GameObject.Destroy()
						end
						local v135 = v471.clonedCharBtn.GetComponent("UnityEngine.UI.Image")
						if v135 ~= nil and v135.IsValid() then
							v135.SetField("color", Vector4.New(1, 1, 1, 0))
						end
						local v142 = v471.clonedCharBtn.GetComponent("RectTransform")
						if v142 ~= nil and v142.IsValid() then
							v142.SetField("sizeDelta", Vector2.New(100, 100))
							v142.SetField("pivot", Vector2.New(0.5, 0.5))
						end
						local v521 = v471.clonedCharBtn.GetComponent("UnityEngine.UI.Button")
						if v521 ~= nil and v521.IsValid() then
							v521.SetField("transition", 0)
							v521.GetField("onClick").AddListener(function()
								v63 = true
								v560 = false
								v549 = false
								v471.profileHidingCredits = true
								local v238 = GameObject.FindByName("Menu/WidgetMaster/4Credits")
								if v238 ~= nil and v238.IsValid() then
									v238.Active = false
								end
								local v540 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Panel")
								if v540 ~= nil and v540.IsValid() then
									v540.Active = false
								end
								local v162 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Text (TMP)")
								if v162 ~= nil and v162.IsValid() then
									v162.Active = false
								end
								if v471.clonedCharBtn ~= nil and v471.clonedCharBtn.IsValid() then
									v471.clonedCharBtn.Active = false
								end
							end)
						end
					end
				end
				if v471.clonedCharBtn ~= nil and v471.clonedCharBtn.IsValid() then
					v471.clonedCharBtn.Active = true
					local v142 = v471.clonedCharBtn.GetComponent("RectTransform")
					if v142 ~= nil and v142.IsValid() then
						v142.SetField("position", Vector3.New(v609.x, v609.y, 0))
					end
				end
			else
				if v471.clonedCharBtn ~= nil and v471.clonedCharBtn.IsValid() then
					v471.clonedCharBtn.Active = false
				end
			end
		end
		if v471.profileHidingCredits then
			if v471.clonedCharBtn ~= nil and v471.clonedCharBtn.IsValid() then
				v471.clonedCharBtn.Active = false
			end
		end
	end
	if v471.profileHidingCredits then
		local v581 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Button (4)")
		if v581 ~= nil and v581.IsValid() then
			local v320 = v581.GetInstanceID()
			if v471.hookedProfileBackBtn ~= v320 then
				local v521 = v581.GetComponent("UnityEngine.UI.Button")
				if v521 ~= nil and v521.IsValid() then
					v521.GetField("onClick").AddListener(function()
						v63 = false
						v471.profileHidingCredits = false
						v560 = true
						local v469 = GameObject.FindByName("Menu/WidgetMaster/0Main")
						if v469 ~= nil and v469.IsValid() then
							v469.Active = false
						end
						local v424 = GameObject.FindByName("Menu/WidgetMaster/4Credits")
						if v424 ~= nil and v424.IsValid() then
							v424.Active = true
						end
						local v388 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Panel")
						if v388 ~= nil and v388.IsValid() then
							v388.Active = true
						end
						local v162 = GameObject.FindByName("Menu/WidgetMaster/7CharacterMenu/Main/Customization/General/Text (TMP)")
						if v162 ~= nil and v162.IsValid() then
							v162.Active = true
						end
					end)
					v471.hookedProfileBackBtn = v320
				end
			end
		end
	end
	if v335 then
		local v69 = v3
		local v454 = v575
		local v270 = (v654 / 2 - v69 / 2) + v329
		local v571 = (v150 / 2 - v454 / 2) + v325
		local v41 = Vector4.New(v270, v571, v69, v454)
		local v169 = v662(5)
		local v317 = Vector4.New(31 / 255, 27 / 255, 27 / 255, 1.0)
		v471.tetoPanelAnim = v471.tetoPanelAnim or 0.0
		v471.isTetoPanelOpen = v471.isTetoPanelOpen or false
		if v471.isTetoPanelOpen then
			v471.tetoPanelAnim = math.min(1.0, v471.tetoPanelAnim + Time.UnscaledDeltaTime * 5.0)
		else
			v471.tetoPanelAnim = math.max(0.0, v471.tetoPanelAnim - Time.UnscaledDeltaTime * 5.0)
		end
		GUI.SetColor(Vector4.New(0, 0, 0, 0.8))
		GUI.Box(v41, "", v471.solidStyle)
		GUI.SetColor(v317)
		GUI.Box(Vector4.New(v41.x, v41.y, v41.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v41.x, v41.y + v41.w - v169, v41.z, v169), "", v471.solidStyle)
		GUI.Box(Vector4.New(v41.x, v41.y, v169, v41.w), "", v471.solidStyle)
		GUI.Box(Vector4.New(v41.x + v41.z - v169, v41.y, v169, v41.w), "", v471.solidStyle)
		GUI.ResetColors()
		GUI.BeginArea(v41)
		local v28 = v662(45)
		local v288 = v662(45)
		local v118 = v69 - v28 - v662(15)
		local v589 = v662(15)
		local v42 = Vector4.New(v118, v589, v28, v288)
		local v304 = Vector4.New(v270 + v118, v571 + v589, v28, v288)
		local v38 = v609.x >= v304.x and v609.x <= v304.x + v304.z and v336 >= v304.y and v336 <= v304.y + v304.w
		local v299 = v38 and Vector4.New(0.15, 0.15, 0.15, 0.9) or Vector4.New(0.05, 0.05, 0.05, 0.9)
		GUI.SetColor(v299)
		GUI.Box(v42, "", v471.solidStyle)
		GUI.ResetColors()
		v497(v42, v662(1), v317)
		local v289 = v471.isTetoPanelOpen and "▼" or "▶"
		local v280 = v38 and v471.btnHoverNoBg or v471.btnNormalNoBg
		if GUI.ButtonRect(v42, "<size=" .. v180(22) .. ">" .. v289 .. "</size>", v280) then
			v471.isTetoPanelOpen = not v471.isTetoPanelOpen
		end
		local v400 = Time.GetRealTimeMs()
		if v471.isColorAnimating then
			if v400 > v471.colorAnimNextTick then
				v471.colorAnimIndex = v471.colorAnimIndex + 1
				if v471.colorAnimIndex > # v592 then
					v471.colorAnimIndex = 1
					v471.colorAnimCycles = v471.colorAnimCycles + 1
				end
				local v308 = (v471.colorAnimCycles >= v471.colorAnimTargetCycles)
				if v308 and v471.colorAnimIndex == v471.colorAnimTargetIndex then
					v471.isColorAnimating = false
					v31 = v471.colorAnimIndex - 1
					File.SetPlayerPrefsStr("nameColor", v31)
				else
					local v456 = 40
					if v308 then
						local v664 = v471.colorAnimTargetIndex - v471.colorAnimIndex
						if v664 < 0 then
							v664 = v664 + # v592
						end
						v456 = 40 + (10 - v664) * 20
					end
					v471.colorAnimNextTick = v400 + v456
				end
			end
			local v226 = (v471.colorAnimIndex - 1) * v662(40)
			if v226 < (v471.colorScrollPos and v471.colorScrollPos.y or 0) then
				v471.colorScrollPos.y = v226
			elseif v226 + v662(40) > (v471.colorScrollPos and v471.colorScrollPos.y or 0) + (v454 - v662(150)) then
				v471.colorScrollPos.y = v226 + v662(40) - (v454 - v662(150))
			end
		end
		local v227 = v471.isColorAnimating and v471.colorAnimIndex or (v31 + 1)
		local v499 = v592[v227]
		local v350 = "玩家名"
		local v60 = Player.GetLocal()
		if v60 ~= nil and v60.IsValid() then
			v350 = v60.GetName()
		end
		local v591 = Vector4.New(v662(20), v662(15), v69 - v662(40), v662(30))
		local v352 = "<align=center><size=" .. v180(20) .. ">预览： <" .. v499 .. "><u>" .. v350 .. "</u></color></size></align>"
		GUI.LabelRect(v591, v352, v568)
		local v321 = v662(600)
		local v431 = (v69 - v321) / 2
		local v635 = v662(650)
		local v130 = (v69 - v635) / 2
		local v112 = Vector4.New(v130, v662(55), v635, v662(30))
		local v277 = Vector4.New(v41.x + v130, v41.y + v662(55), v635, v662(30))
		local v441 = v609.x >= v277.x and v609.x <= v277.x + v277.z and v336 >= v277.y and v336 <= v277.y + v277.w
		local v459 = v441 and Vector4.New(0.15, 0.15, 0.15, 0.9) or Vector4.New(0.05, 0.05, 0.05, 0.9)
		GUI.SetColor(v459)
		GUI.Box(v112, "", v471.solidStyle)
		GUI.ResetColors()
		v497(v112, v662(1), v317)
		if GUI.ButtonRect(v112, "<size=" .. v180(18) .. ">随机颜色</size>", v441 and v471.creditsTextHover or v471.creditsTextNormal) then
			if not v471.isColorAnimating then
				v471.isColorAnimating = true
				v471.colorAnimIndex = v227
				v471.colorAnimTargetIndex = math.random(1, # v592)
				v471.colorAnimCycles = 0
				v471.colorAnimTargetCycles = math.random(2, 4)
				v471.colorAnimNextTick = v400
			end
		end
		v471.colorScrollPos = v471.colorScrollPos or Vector2.New(0, 0)
		local v555 = Input.GetAxis("Mouse ScrollWheel")
		local v657 = v662(100)
		local v428 = v454 - v657 - v662(10)
		if v428 < v662(50) then
			v428 = v662(50)
		end
		local v217 = v609.x >= v41.x and v609.x <= v41.x + v69 and v336 >= v41.y + v657 and v336 <= v41.y + v657 + v428
		if v555 and v555 ~= 0 and v217 then
			v471.colorScrollPos.y = math.max(0, v471.colorScrollPos.y - v555 * v662(100))
		end
		GUI.BeginArea(Vector4.New(0, v657, v69, v428))
		v471.colorScrollPos = GUI.BeginScrollView(v471.colorScrollPos, v69, v428)
		GUI.Space(# v592 * v662(40))
		for colorCode, colorHex in tableIterators.ipairs(v592) do
			local v226 = (colorCode - 1) * v662(40)
			local v182 = Vector4.New(v431, v226, v321, v662(30))
			local v2 = Vector4.New(v41.x + v431, v41.y + v657 + v226 - v471.colorScrollPos.y, v321, v662(30))
			local v12 = v217 and v609.x >= v2.x and v609.x <= v2.x + v2.z and v336 >= v2.y and v336 <= v2.y + v2.w
			local v539 = v471.isColorAnimating and (colorCode == v471.colorAnimIndex) or (not v471.isColorAnimating and colorCode - 1 == v31)
			if v226 - v471.colorScrollPos.y > v662(- 40) and v226 - v471.colorScrollPos.y < v428 then
				local v496 = Vector4.New(0.05, 0.05, 0.05, 0.9)
				if v539 then
					v496 = Vector4.New(0.3, 0.3, 0.3, 0.9)
				elseif v12 then
					v496 = Vector4.New(0.15, 0.15, 0.15, 0.9)
				end
				GUI.SetColor(v496)
				GUI.Box(v182, "", v471.solidStyle)
				GUI.ResetColors()
				v497(v182, v662(1), v317)
				local v307 = GUI.ButtonRect(v182, "", v171)
				local v88 = "Параллелипипед"
				if colorCode == 3 then
					v88 = "!димас_морозилка_2016_67_52_42"
				elseif colorCode == 7 then
					v88 = "MrSenoteko"
				end
				local v125 = "<size=" .. v180(18) .. "><color=" .. colorHex .. ">"
				if v539 then
					v125 = v125 .. "<u>" .. v88 .. "</u>"
				else
					v125 = v125 .. v88
				end
				v125 = v125 .. "</color></size>"
				GUI.LabelRect(Vector4.New(v182.x, v182.y + v608, v182.z, v182.w), v125, v471.colorItemSty)
				if v307 then
					v31 = colorCode - 1
					File.SetPlayerPrefsStr("nameColor", v31)
					v471.isColorAnimating = false
				end
			end
		end
		GUI.EndScrollView()
		GUI.EndArea()
		GUI.EndArea()
		if v471.tetoPanelAnim > 0.001 and v590 and v317 and v568 then
			local v214 = v69
			local v356 = v662(120) * v471.tetoPanelAnim
			local v558 = v270
			local v174 = v571 + v454 - v169
			local v9 = Vector4.New(v558, v174, v214, v356)
			GUI.SetColor(Vector4.New(0, 0, 0, 0.8))
			GUI.Box(v9, "", v471.solidStyle)
			GUI.SetColor(v317)
			GUI.Box(Vector4.New(v9.x, v9.y, v9.z, v169), "", v471.solidStyle)
			GUI.Box(Vector4.New(v9.x, v9.y + v9.w - v169, v9.z, v169), "", v471.solidStyle)
			GUI.Box(Vector4.New(v9.x, v9.y, v169, v9.w), "", v471.solidStyle)
			GUI.Box(Vector4.New(v9.x + v9.z - v169, v9.y, v169, v9.w), "", v471.solidStyle)
			GUI.ResetColors()
			GUI.BeginArea(v9)
			GUI.LabelRect(Vector4.New(v662(20), v662(15) + v608, v662(200), v662(30)), "<size=" .. v180(20) .. "><b>超秘密管理设置 [开发] 超级秘密，请勿触碰</b></size>", v568)
			local v305 = Vector4.New(v662(20), v662(55), v662(250), v662(38))
			local v463 = v609.x >= (v9.x + v662(20)) and v609.x <= (v9.x + v662(270)) and v336 >= (v9.y + v662(55)) and v336 <= (v9.y + v662(93))
			local v530 = v463 and "#ff4444" or "#ffffff"
			local v377 = v471.showTetoOverlay and "☑ " or "☐ "
			local v481 = "<color=" .. v530 .. ">" .. v377 .. "</color>"
			if GUI.ButtonRect(v305, "<size=" .. v180(16) .. ">" .. v481 .. "我是couvae</size>", v568) then
				v471.showTetoOverlay = not v471.showTetoOverlay
				File.SetPlayerPrefsStr("showTetoOverlay", v471.showTetoOverlay and "true" or "false")
			end
			GUI.EndArea()
		end
	end
	local v394 = EnvironmentMaster.GetCurrentScene()
	local v554 = (v394 == "sys_Menu" or v394 == "MapMaker")
	if v471.isInGameMenuOpen and not v554 and v471.activeCurrentPanel ~= nil and v471.activeCurrentPanel.IsValid() then
		local v354 = (v471.activeCurrentPanel == v471.cachedMenuRestricted)
		local v379 = v354 and 803.0 or 640.0
		local v201 = v471.activeCurrentPanel.Transform.Find("ServerNameBG")
		if v201 ~= nil and v201.GameObject.Active then
			v379 = v354 and 803.0 or 700.0
		end
		local v107 = v150 / 1080.0
		local v476 = v379 * v107
		local v408 = 73.0 * v107
		local v528 = Vector4.New(v662(v548), v476, v662(v156), v408)
		local v496 = Vector4.New(34 / 255, 32 / 255, 31 / 255, 0.5)
		local v119 = Vector4.New(120 / 255, 120 / 255, 120 / 255, 0.5)
		GUI.SetColor(v496)
		GUI.Box(v528, "", v471.solidStyle)
		GUI.ResetColors()
		v497(v528, v662(4), v119)
		local v445 = v609.x >= v528.x and v609.x <= v528.x + v528.z and v336 >= v528.y and v336 <= v528.y + v528.w
		local v264 = v445 and Input.GetMouse(0)
		if GUI.ButtonRect(v528, "", v471.btnNormalNoBg) then
			v471.isMPModMenuOpen = true
		end
		if v471.mpModTex ~= nil and v471.mpModTex.IsValid() then
			GUI.SetColor(Vector4.New(1, 1, 1, 1))
			GUI.DrawTexture(Vector4.New(v528.x + v662(15), v528.y + (v408 - v662(32)) / 2, v662(32), v662(32)), v471.mpModTex, "StretchToFill", true, 1)
			GUI.ResetColors()
		end
		GUI.LabelRect(Vector4.New(v528.x + v662(65), v528.y + v608, v528.z - v662(65), v528.w), "<size=" .. v180(22) .. "><b>MPMod</b></size>", v264 and v471.menuBtnTextPressed or v471.menuBtnTextNormal)
		if v471.isMPModMenuOpen then
			v471.mpModActiveTab = v471.mpModActiveTab or "Players"
			local v645 = v662(64)
			local v355 = v662(15)
			local v646 = (v150 / v520) - v639 - 16.0
			local v375 = Vector4.New(v662(v87), v662(v639), v662(v503), v662(v646))
			local v396 = Vector4.New(v662(v87), v662(v639), v662(v503), v662(v429))
			local v246 = Vector4.New(v662(v87), v662(v639) - v645 - v355, v662(v503), v645)
			GUI.SetColor(Vector4.New(20 / 255, 20 / 255, 20 / 255, 0.5))
			GUI.Box(v246, "", v471.solidStyle)
			GUI.ResetColors()
			if not v532 and v471.mpModActiveTab == "Gamemode" then
				v471.mpModActiveTab = "Players"
			end
			local v618 = v662(10)
			local v228 = v532 and ((v662(v503) - v618) / 2) or v662(v503)
			local v518 = Vector4.New(34 / 255, 32 / 255, 31 / 255, 0.5)
			local v450 = Vector4.New(120 / 255, 120 / 255, 120 / 255, 0.5)
			local v517 = Vector4.New(v246.x, v246.y, v228, v645)
			local v247 = v609.x >= v517.x and v609.x <= v517.x + v517.z and v336 >= v517.y and v336 <= v517.y + v517.w
			local v420 = v247 and Input.GetMouse(0)
			GUI.SetColor(v518)
			GUI.Box(v517, "", v471.solidStyle)
			GUI.ResetColors()
			v497(v517, v662(5), v450)
			if GUI.ButtonRect(v517, "", v471.btnNormalNoBg) then
				v471.mpModActiveTab = "Players"
			end
			local v56 = v420 and v471.menuBtnTextPressed or v471.menuBtnTextNormal
			if v471.playersTabTex and v471.playersTabTex.IsValid() then
				GUI.SetColor(Vector4.New(1, 1, 1, v420 and 0.7 or 1))
				GUI.DrawTexture(Vector4.New(v517.x + (v228 / 2) - v662(55), v517.y + (v645 - v662(22)) / 2, v662(27), v662(22)), v471.playersTabTex, "ScaleToFit", true, 0)
				GUI.ResetColors()
			end
			GUI.LabelRect(Vector4.New(v517.x + (v228 / 2) - v662(15), v517.y + v608, v228, v645), "<size=" .. v180(22) .. ">玩家</size>", v56)
			if v532 then
				local v312 = Vector4.New(v246.x + v228 + v618, v246.y, v228, v645)
				local v80 = v609.x >= v312.x and v609.x <= v312.x + v312.z and v336 >= v312.y and v336 <= v312.y + v312.w
				local v279 = v80 and Input.GetMouse(0)
				GUI.SetColor(v518)
				GUI.Box(v312, "", v471.solidStyle)
				GUI.ResetColors()
				v497(v312, v662(5), v450)
				if GUI.ButtonRect(v312, "", v471.btnNormalNoBg) then
					v471.mpModActiveTab = "Gamemode"
				end
				local v361 = v279 and v471.menuBtnTextPressed or v471.menuBtnTextNormal
				if v471.gamemodeTabTex and v471.gamemodeTabTex.IsValid() then
					GUI.SetColor(Vector4.New(1, 1, 1, v279 and 0.7 or 1))
					GUI.DrawTexture(Vector4.New(v312.x + (v228 / 2) - v662(115), v312.y + (v645 - v662(32)) / 2, v662(32), v662(32)), v471.gamemodeTabTex, "ScaleToFit", true, 0)
					GUI.ResetColors()
				end
				GUI.LabelRect(Vector4.New(v312.x + (v228 / 2) - v662(70), v312.y + v608, v228, v645), "<size=" .. v180(22) .. ">游戏模式编辑器</size>", v361)
			end
			GUI.SetColor(v496)
			GUI.Box(v375, "", v471.solidStyle)
			GUI.SetColor(Vector4.New(20 / 255, 20 / 255, 20 / 255, 0.5))
			GUI.Box(v396, "", v471.solidStyle)
			GUI.ResetColors()
			v497(v375, v662(4), v119)
			if v471.mpModActiveTab == "Players" then
				local v566 = # v296
				local v151 = math.min(v566, 255)
				if v222 ~= nil and v222 ~= "" then
					GUI.LabelRect(Vector4.New(v396.x + v662(15), v396.y + v608, v662(200), v396.w), "<size=" .. v180(20) .. ">MPMod - 玩家</size>", v471.menuBtnTextNormal)
					GUI.BeginArea(Vector4.New(v396.x + v662(220), v396.y + v662(4), v396.z - v662(240), v396.w - v662(8)))
					local v292 = GUI.NewStyle()
					v292.background = v634.background
					v292.normalTextColor = v634.normalTextColor
					v292.alignment = "MiddleLeft"
					v292.wordWrap = false
					local v603 = GUI.TextArea("<size=" .. v180(14) .. ">" .. v222 .. "</size>", 1024, v396.z - v662(240), v396.w - v662(8), v292)
					if v603 then
						v603 = string.gsub(v603, "<size=%d+>", "")
						v603 = string.gsub(v603, "</size>", "")
						if v603 ~= v222 then
							v222 = v603
							v442(v222)
						end
					end
					GUI.EndArea()
				else
					GUI.LabelRect(Vector4.New(v396.x + v662(15), v396.y + v608, v396.z - v662(30), v396.w), "<size=" .. v180(20) .. ">MPMod - 玩家</size>", v471.menuBtnTextNormal)
				end
				GUI.SetColor(v119)
				GUI.Box(Vector4.New(v396.x, v396.y + v396.w, v396.z, v662(4)), "", v471.solidStyle)
				GUI.ResetColors()
				local v421 = v396.y + v396.w + v662(15)
				local v509 = v662(v503) - v662(30)
				local v282 = v662(v284) - v662(v429) - v662(30)
				local v510 = Vector4.New(v396.x + v662(15), v421, v509, v282)
				if v471.showTetoOverlay and v471.tetoTex ~= nil and v471.tetoTex.IsValid() then
					local v542 = v662(400)
					local v432 = v662(400)
					local v619 = v509 - v542
					local v116 = v282 - v432
					GUI.SetColor(Vector4.New(1, 1, 1, 0.15))
					GUI.DrawTexture(Vector4.New(v396.x + v619, v421 + v116, v542, v432), v471.tetoTex, "ScaleToFit", true, 0)
					GUI.ResetColors()
				end
				local v61 = v662(50)
				local v208 = v662(45)
				local v223 = v662(8)
				local v32 = v61 + v223
				local v81 = v208 + v223
				local v436 = {}
				local v331 = 0
				for v531 = 1, v151 do
					v436[v531] = v331
					local v285 = (v471.mpModSelectedPlayerIndex == v531)
					v331 = v331 + v32
					if v285 and v532 then
						v331 = v331 + v81
					end
				end
				v471.mpModScroll = v471.mpModScroll or Vector2.New(0, 0)
				local v597 = Input.GetAxis("Mouse ScrollWheel")
				if v597 and v597 ~= 0 then
					if v609.x >= v510.x and v609.x <= v510.x + v510.z and v336 >= v510.y and v336 <= v510.y + v510.w then
						local v109 = math.max(0, v331 - v282)
						v471.mpModScroll.y = math.max(0, math.min(v109, v471.mpModScroll.y - v597 * v662(100)))
					end
				end
				GUI.BeginArea(v510)
				v471.mpModScroll = GUI.BeginScrollView(v471.mpModScroll, v509, v282)
				GUI.Space(v331)
				for v531 = 1, v151 do
					local v260 = v436[v531]
					local v285 = (v471.mpModSelectedPlayerIndex == v531)
					local v48 = v32 + (v285 and v532 and v81 or 0)
					if v260 + v48 > v471.mpModScroll.y and v260 < v471.mpModScroll.y + v282 then
						if v296[v531] ~= nil then
							local v475 = v296[v531].ToUnknownType()
							local v570 = v438(v475)
							local v334 = string.gsub(v570, "^%d+%s*", "")
							local v389 = string.gsub(v334, "[\n><\\]", "")
							local v62 = string.sub(v389, 1, 18)
							local v163 = string.format("%02d", v531)
							local v125 = "[" .. v163 .. "] " .. v62
							local v21 = false
							if v94 and v94[v570] and v94[v570].host then
								v21 = true
							end
							local v343 = Vector4.New(0, v260, v509 - v662(10), v61)
							local v516 = Vector4.New(v510.x, v510.y + v260 - v471.mpModScroll.y, v509 - v662(10), v61)
							local v12 = v609.x >= v516.x and v609.x <= v516.x + v516.z and v336 >= v516.y and v336 <= v516.y + v516.w
							local v6 = v12 and Input.GetMouse(0)
							local v161 = (v471.mpModPressTargetIndex == v531) and (v105 - (v471.mpModRowPressTime or 0) < 250)
							local v158 = Vector4.New(0.1, 0.1, 0.1, 0.7)
							if v161 or v6 then
								v158 = Vector4.New(0.3, 0.3, 0.3, 0.8)
							elseif v12 then
								v158 = Vector4.New(0.2, 0.2, 0.2, 0.8)
							end
							GUI.SetColor(v158)
							GUI.Box(v343, "", v471.solidStyle)
							GUI.ResetColors()
							v497(v343, v662(2), v119)
							if GUI.ButtonRect(v343, "", v471.btnNormalNoBg) then
								if v471.mpModSelectedPlayerIndex == v531 then
									v471.mpModSelectedPlayerIndex = nil
								else
									v471.mpModSelectedPlayerIndex = v531
								end
								v471.mpModRowPressTime = v105
								v471.mpModPressTargetIndex = v531
							end
							local v166 = v6 and v471.playerListTextPressed or v471.playerListTextNormal
							if v21 and v471.hostTex and v471.hostTex.IsValid() then
								GUI.SetColor(Vector4.New(200 / 255, 180 / 255, 50 / 255, 1))
								GUI.DrawTexture(Vector4.New(v343.x + v662(20), v343.y + (v61 - v662(26)) / 2, v662(26), v662(26)), v471.hostTex, "ScaleToFit", true, 0)
								GUI.ResetColors()
								GUI.LabelRect(Vector4.New(v343.x + v662(56), v343.y + v608, v343.z - v662(56), v343.w), "<size=" .. v180(20) .. ">" .. v125 .. "</size>", v166)
							else
								GUI.LabelRect(Vector4.New(v343.x + v662(20), v343.y + v608, v343.z - v662(20), v343.w), "<size=" .. v180(20) .. ">" .. v125 .. "</size>", v166)
							end
							local v652 = v438(Player.GetLocal().ToUnknownType())
							if v285 and v532 and v570 ~= v652 then
								local v319 = v260 + v61 + v223
								local v191 = (v509 - v662(10) - v223) / 2
								local v59 = v662(80)
								local v211 = v191 - v59 - v662(4)
								local v261 = Vector4.New(0, v319, v59, v208)
								local v274 = Vector4.New(v59 + v662(4), v319, v211, v208)
								local v185 = Vector4.New(v510.x, v510.y + v319 - v471.mpModScroll.y, v191, v208)
								local v425 = v609.x >= v185.x and v609.x <= v185.x + v185.z and v336 >= v185.y and v336 <= v185.y + v185.w
								local v630 = Vector4.New(160 / 255, 140 / 255, 30 / 255, v425 and 0.8 or 0.4)
								local v616 = Vector4.New(40 / 255, 35 / 255, 10 / 255, 0.8)
								local v649 = Vector4.New(200 / 255, 180 / 255, 50 / 255, 1)
								GUI.SetColor(v616)
								GUI.Box(v261, "", v471.solidStyle)
								GUI.Box(v274, "", v471.solidStyle)
								GUI.ResetColors()
								v497(v261, v662(2), v630)
								v497(v274, v662(2), v630)
								if GUI.ButtonRect(Vector4.New(0, v319, v191, v208), "", v471.btnNormalNoBg) then
									v138(v570)
									Server.SendChatMessage("<color=yellow>已将主机转移给 " .. v570, 15)
									v210("<color=yellow>已将主机转移给 " .. v570)
								end
								if v471.hostTex and v471.hostTex.IsValid() then
									GUI.SetColor(v649)
									GUI.DrawTexture(Vector4.New(v261.x + (v59 - v662(36)) / 2, v261.y + (v208 - v662(36)) / 2, v662(36), v662(36)), v471.hostTex, "ScaleToFit", true, 0)
									GUI.ResetColors()
								end
								GUI.LabelRect(Vector4.New(v274.x, v274.y + v608, v274.z, v274.w), "<size=" .. v180(18) .. "><color=#c8b432>转移主机</color></size>", v471.playerListTextNormal)
								local v670 = v191 + v223
								local v53 = Vector4.New(v670, v319, v59, v208)
								local v267 = Vector4.New(v670 + v59 + v662(4), v319, v211, v208)
								local v283 = Vector4.New(v510.x + v670, v510.y + v319 - v471.mpModScroll.y, v191, v208)
								local v120 = v609.x >= v283.x and v609.x <= v283.x + v283.z and v336 >= v283.y and v336 <= v283.y + v283.w
								local v241 = Vector4.New(160 / 255, 50 / 255, 40 / 255, v120 and 0.8 or 0.4)
								local v230 = Vector4.New(40 / 255, 15 / 255, 10 / 255, 0.8)
								local v658 = Vector4.New(200 / 255, 70 / 255, 50 / 255, 1)
								GUI.SetColor(v230)
								GUI.Box(v53, "", v471.solidStyle)
								GUI.Box(v267, "", v471.solidStyle)
								GUI.ResetColors()
								v497(v53, v662(2), v241)
								v497(v267, v662(2), v241)
								if GUI.ButtonRect(Vector4.New(v670, v319, v191, v208), "", v471.btnNormalNoBg) then
									v126(v570, "房主已将你踢出")
									Server.SendChatMessage("<color=yellow>" .. v570 .. " 已被踢出", 10)
									v210("<color=yellow>" .. v570 .. " 已被踢出")
								end
								if v471.kickTex and v471.kickTex.IsValid() then
									GUI.SetColor(v658)
									GUI.DrawTexture(Vector4.New(v53.x + (v59 - v662(36)) / 2, v53.y + (v208 - v662(36)) / 2, v662(36), v662(36)), v471.kickTex, "ScaleToFit", true, 0)
									GUI.ResetColors()
								end
								GUI.LabelRect(Vector4.New(v267.x, v267.y + v608, v267.z, v267.w), "<size=" .. v180(18) .. "><color=#c84632>踢出</color></size>", v471.playerListTextNormal)
							end
						end
					end
				end
				GUI.EndScrollView()
				GUI.EndArea()
			elseif v471.mpModActiveTab == "Gamemode" then
				GUI.LabelRect(Vector4.New(v396.x + v662(15), v396.y + v608, v396.z - v662(30), v396.w), "<size=" .. v180(20) .. ">MPMod - 游戏模式编辑器</size>", v471.menuBtnTextNormal)
				GUI.SetColor(v119)
				GUI.Box(Vector4.New(v396.x, v396.y + v396.w, v396.z, v662(4)), "", v471.solidStyle)
				GUI.ResetColors()
				local v421 = v396.y + v396.w + v662(20)
				local v665 = v421
				local v45 = v396.x + v662(20)
				local v667 = v45
				local v648 = v45 + v662(350)
				local v397 = v662(320)
				local v143 = v662(35)
				local function v196(rect, label, v164)
					local v12 = v609.x >= rect.x and v609.x <= rect.x + rect.z and v336 >= rect.y and v336 <= rect.y + rect.w
					local v489 = v12 and "#ff5555" or (v164 and "#55ff55" or "#ffffff")
					local v377 = v164 and "☑ " or "☐ "
					local v14 = "<size=" .. v180(20) .. "><color=" .. v489 .. ">" .. v377 .. "</color>" .. label .. "</size>"
					local v33 = GUI.NewStyle()
					v33.normalTextColor = Vector4.New(1, 1, 1, 1)
					v33.alignment = "MiddleLeft"
					if GUI.ButtonRect(rect, v14, v33) then
						return not v164
					end
					return v164
				end
				if v532 then
					v573 = v196(Vector4.New(v667, v665, v397, v143), "启用GBRP", v573)
					v650 = v196(Vector4.New(v648, v665, v397, v143), "空中控制", v650)
					v451 = v650
					v665 = v665 + v662(45)
					v114 = v196(Vector4.New(v667, v665, v397, v143), "禁止交互", v114)
					v137 = v114
					v91 = v196(Vector4.New(v648, v665, v397, v143), "锁定状态", v91)
					v502 = v91
					v665 = v665 + v662(45)
					v36 = v196(Vector4.New(v667, v665, v397, v143), "禁止连跳", v36)
					v176 = v36
					v406 = v196(Vector4.New(v648, v665, v397, v143), "允许帽子", v406)
					v103 = v406
				else
					GUI.LabelRect(Vector4.New(v45, v665, v662(800), v662(30)), "<size=" .. v180(20) .. "><color=#ff4444>只有主机可以编辑游戏模式设置。</color></size>", v568)
					v665 = v665 + v662(40)
					v196(Vector4.New(v667, v665, v397, v143), "启用GBRP", v573)
					v196(Vector4.New(v648, v665, v397, v143), "空中控制", v650)
					v665 = v665 + v662(45)
					v196(Vector4.New(v667, v665, v397, v143), "禁止交互", v114)
					v196(Vector4.New(v648, v665, v397, v143), "锁定状态", v91)
					v665 = v665 + v662(45)
					v196(Vector4.New(v667, v665, v397, v143), "禁止连跳", v36)
					v196(Vector4.New(v648, v665, v397, v143), "允许帽子", v406)
				end
			end
		end
	end
end
local function v353()
	v409.CallMethod("OpLeaveRoom", false, true)
	EnvironmentMaster.LoadScene("sys_Menu")
	v195.SetField("players", {})
end
function Update()
	v105 = Time.GetRealTimeMs()
	if EnvironmentMaster.GetCurrentScene() == "sys_Menu" then
		local v272 = GameObject.FindByName("Play")
		if v272 == nil or not v272.IsValid() then
			v272 = GameObject.FindByName("PlayButton")
		end
		if v272 == nil or not v272.IsValid() then
			v272 = GameObject.FindByName("Button_Play")
		end
		if v272 ~= nil and v272.IsValid() and v272.Active then
			local v207 = v272.GetComponent("RectTransform")
			if v207 == nil or not v207.IsValid() then
				v207 = v272.GetComponent("Transform")
			end
			if v207 ~= nil and v207.IsValid() then
				local v632 = v207.GetField("localPosition")
				if v632 ~= nil then
					local v23 = GameObject.FindByName("Credits")
					if v23 == nil or not v23.IsValid() then
						v23 = GameObject.FindByName("CreditsButton")
					end
					if v23 == nil or not v23.IsValid() then
						v23 = GameObject.FindByName("Button_Credits")
					end
					if v23 ~= nil and v23.IsValid() then
						local v347 = v23.GetComponentInChildren("TextMeshProUGUI")
						if v347 == nil or not v347.IsValid() then
							v347 = v23.GetComponentInChildren("Text")
						end
						if v347 ~= nil and v347.IsValid() then
							local v444 = v23.Name
							if v444 ~= "Back" and v444 ~= "Button_Back" and v444 ~= "Back (4)" then
								v347.SetField("text", "MPMod")
							end
						end
						local v391 = v23.GetComponent("RectTransform")
						if v391 == nil or not v391.IsValid() then
							v391 = v23.GetComponent("Transform")
						end
						if v391 ~= nil and v391.IsValid() then
							v391.SetField("localPosition", Vector3.New(v632.x + 380, v632.y, v632.z))
						end
					end
					local v359 = GameObject.FindByName("Settings")
					if v359 == nil or not v359.IsValid() then
						v359 = GameObject.FindByName("SettingsButton")
					end
					if v359 ~= nil and v359.IsValid() then
						local v433 = v359.GetComponent("RectTransform")
						if v433 == nil or not v433.IsValid() then
							v433 = v359.GetComponent("Transform")
						end
						if v433 ~= nil and v433.IsValid() then
							v433.SetField("localPosition", Vector3.New(v632.x + 760, v632.y, v632.z))
						end
					end
					local v552 = GameObject.FindByName("Addons")
					if v552 == nil or not v552.IsValid() then
						v552 = GameObject.FindByName("AddonsButton")
					end
					if v552 == nil or not v552.IsValid() then
						v552 = GameObject.FindByName("Workshop")
					end
					if v552 ~= nil and v552.IsValid() then
						local v380 = v552.GetComponent("RectTransform")
						if v380 == nil or not v380.IsValid() then
							v380 = v552.GetComponent("Transform")
						end
						if v380 ~= nil and v380.IsValid() then
							v380.SetField("localPosition", Vector3.New(v632.x + 1140, v632.y, v632.z))
						end
					end
				end
			end
		end
		if not v250 then
			local v144 = {
				"Menu/WidgetMaster/4Credits/Holder",
				"Menu/WidgetMaster/4Credits/Holder/Copyright",
				"Menu/WidgetMaster/4Credits/Holder/Title",
				"Menu/WidgetMaster/4Credits/Holder/DC(1)",
				"Menu/WidgetMaster/4Credits/Holder/Holder",
				"Menu/WidgetMaster/4Credits/Holder/Field",
				"Menu/WidgetMaster/4Credits/Holder/DC",
				"Menu/WidgetMaster/4Credits/ButtonBottomHolder (1)",
				"Menu/WidgetMaster/4Credits/Holder/DC (1)"
			}
			for v531 = 1, # v144 do
				local v268 = v144[v531]
				local v121 = GameObject.FindByName(v268)
				if v121 ~= nil and v121.IsValid() then
					v121.Destroy()
				end
			end
			if GameObject.FindByName("Menu/WidgetMaster/4Credits") ~= nil then
				v250 = true
			end
		end
	else
		v250 = false
		local v394 = EnvironmentMaster.GetCurrentScene()
		local v554 = (v394 == "sys_Menu" or v394 == "MapMaker")
		if v554 then
			v471.isMPModMenuOpen = false
			v471.isInGameMenuOpen = false
		else
			if v471.lastCanvasCheck == nil then
				v471.lastCanvasCheck = 0
			end
			if v105 > v471.lastCanvasCheck + 500 then
				v471.lastCanvasCheck = v105
				if v471.cachedGameCanvas == nil or not v471.cachedGameCanvas.IsValid() then
					v471.cachedGameCanvas = GameObject.FindByName("GameCanvas-3")
				end
				if v471.cachedGameCanvas ~= nil and v471.cachedGameCanvas.IsValid() then
					if v471.cachedMenuPanel == nil or not v471.cachedMenuPanel.IsValid() then
						local v315 = v471.cachedGameCanvas.Transform.Find("PanelManager/MenuPanel")
						if v315 ~= nil then
							v471.cachedMenuPanel = v315.GameObject
						end
					end
					if v471.cachedMenuRestricted == nil or not v471.cachedMenuRestricted.IsValid() then
						local v519 = v471.cachedGameCanvas.Transform.Find("PanelManager/MenuPanel (NewRestricted)")
						if v519 ~= nil then
							v471.cachedMenuRestricted = v519.GameObject
						end
					end
					if v471.cachedSpacer == nil or not v471.cachedSpacer.IsValid() then
						local v315 = v471.cachedGameCanvas.Transform.Find("PanelManager/MenuPanel")
						if v315 ~= nil then
							local v168 = v315.Find("PanelCategories")
							if v168 ~= nil then
								local v213 = v168.Find("ServerSettings")
								if v213 ~= nil then
									local v4 = v213.GetSiblingIndex()
									if v4 > 0 then
										local v640 = v168.GetChild(v4 - 1)
										if v640.GameObject.Name == "spacer" then
											v471.cachedSpacer = v640
										end
									end
								end
							end
						end
					end
				end
			end
			if v471.cachedSpacer ~= nil and v471.cachedSpacer.IsValid() then
				local v622 = v471.cachedSpacer.LocalScale
				if v622.y ~= v422 then
					v622.y = v422
					v471.cachedSpacer.LocalScale = v622
				end
			end
			local v300 = (v471.cachedMenuPanel ~= nil and v471.cachedMenuPanel.IsValid() and v471.cachedMenuPanel.Active)
			local v170 = (v471.cachedMenuRestricted ~= nil and v471.cachedMenuRestricted.IsValid() and v471.cachedMenuRestricted.Active)
			if v471.cachedGameCanvas ~= nil and v471.cachedGameCanvas.IsValid() and (v300 or v170) then
				v471.isInGameMenuOpen = v471.cachedGameCanvas.Active
				v471.activeCurrentPanel = v300 and v471.cachedMenuPanel or v471.cachedMenuRestricted
			else
				v471.isInGameMenuOpen = false
				v471.activeCurrentPanel = nil
			end
		end
		if v471.isInGameMenuOpen and not v554 and v471.activeCurrentPanel ~= nil and v471.activeCurrentPanel.IsValid() then
			local v173 = v471.activeCurrentPanel.Transform.Find("PanelHolder")
			if v173 ~= nil then
				local v354 = (v471.activeCurrentPanel == v471.cachedMenuRestricted)
				if v471.isMPModMenuOpen and not v471.wasMPModOpen then
					if v354 then
						local v301 = {
							"Player Settings",
							"Players",
							"Optimization",
							"Misc",
							"Report"
						}
						for _, subName in tableIterators.ipairs(v301) do
							local v604 = v173.Find(subName)
							if v604 ~= nil and v604.GameObject.Active then
								v604.GameObject.Active = false
							end
						end
					else
						for v531 = 0, v173.ChildCount - 1 do
							local v411 = v173.GetChild(v531).GameObject
							if v411.Active then
								v411.Active = false
							end
						end
					end
				elseif v471.isMPModMenuOpen and v471.wasMPModOpen then
					local v498 = false
					if v354 then
						local v301 = {
							"Player Settings",
							"Players",
							"Optimization",
							"Misc",
							"Report"
						}
						for _, subName in tableIterators.ipairs(v301) do
							local v604 = v173.Find(subName)
							if v604 ~= nil and v604.GameObject.Active then
								v498 = true
								break
							end
						end
					else
						for v531 = 0, v173.ChildCount - 1 do
							local v411 = v173.GetChild(v531).GameObject
							if v411.Active then
								v498 = true
								break
							end
						end
					end
					if v498 then
						v471.isMPModMenuOpen = false
					end
				end
			end
			local v381 = v471.activeCurrentPanel.Transform.Find("ReturnMenu")
			if v381 ~= nil and v381.GameObject.Active then
				v471.isMPModMenuOpen = false
			end
			v471.wasMPModOpen = v471.isMPModMenuOpen
		else
			v471.wasMPModOpen = v471.isMPModMenuOpen
		end
	end
	if v650 == true then
		if PlayerMaster.IsValid() and not PlayerMaster.Grounded then
			v526()
			if controllerComp ~= nil and controllerComp.IsValid() then
				controllerComp.SetField("isGrounded", true)
			end
		end
	end
	v368 = v368 + (Time.UnscaledDeltaTime - v368) * 0.02
	if v105 > v77 + (v136 and 500 or 1500) then
		v77 = v105
		local v100 = basicModule.tostring(v409.GetField("State") or "Unknown")
		if v100 ~= v164 then
			v164 = v100
			v500 = v105
		end
		v447 = basicModule.tostring(v409.GetField("CurrentServerAddress") or "Not Connected")
		v332 = basicModule.tostring(v409.GetField("CloudRegion"))
		v64 = v556.CallMethod("Invoke", nil, nil) or 0
		v195 = v204()
		if v195 then
			v384 = string.gsub(v195.GetField("Name"), ", .*", "")
			v511 = v195.GetField("players") or {}
			for v531 = 1, # v511 do
				v511[v531] = v511[v531].GetField("value")
			end
			if EnvironmentMaster.GetCurrentScene() == "sys_Menu" then
				if not v136 then
					v385 = 0
					v452(true)
				end
				v136 = true
			else
				if v136 then
					v136 = false
					PhotonNetwork.CallMethod("GetMethod", "set_IsMessageQueueRunning").CallMethod("Invoke", nil, true)
					v63 = false
					v560 = false
					v452(false)
					v333[coroutine.create(function()
						v385 = 0
						v22 = 0
						local v249 = GameObject.FindAllByComponent("GameMaster")
						if # v249 > 0 then
							local v189 = v249[1].Transform
							local v372 = v189.Find("GameCanvas-3/PanelManager/MenuPanel/ReturnMenu/Button")
							local v234 = v189.Find("GameCanvas-3/PanelManager/MenuPanel (NewRestricted)/ReturnMenu/Button")
							if v372 ~= nil then
								local v113 = v372.GameObject.GetComponent("UnityEngine.UI.Button")
								if v113 then
									v113.GetField("onClick").AddListener(function()
										v353()
										v452(true)
									end)
								end
							end
							if v234 ~= nil then
								local v562 = v234.GameObject.GetComponent("UnityEngine.UI.Button")
								if v562 then
									v562.GetField("onClick").AddListener(function()
										v353()
										v452(true)
									end)
								end
							end
							local v213 = v189.Find("GameCanvas-3/PanelManager/MenuPanel/PanelCategories/ServerSettings")
							if v213 ~= nil then
								v213.GameObject.Active = true
							end
							local v585 = GameObject.FindAllByComponent("ServerPanel")
							if # v585 > 0 then
								local v653 = v585[1].GetComponent("ServerPanel")
								local v254 = v653.GetField("infoPrefab")
								if v254 ~= nil then
									local v98 = v254.GameObject.Transform.Find("Options (OBD)/TransferHost")
									if v98 ~= nil then
										v98.LocalScale = Vector3.Zero
									end
								end
							end
							v296 = Player.GetAllPlayers()
						end
					end)] = v105 + 1000
				end
				v136 = false
			end
		else
			v136 = true
			v384 = ""
			v195 = nil
			v511 = {}
			v94 = {}
			v464 = {}
			v242 = v84()
			v106 = 1
			string.gsub(v242, ".", function(v167)
				v106 = (v106 * 123 + string.byte(v167)) % 123456789
			end)
			v106 = string.format("%06x", v106)
			v106 = string.gsub(v106, ".", function(v167)
				return string.char(103 + basicModule.tonumber(v167, 16))
			end)
		end
	end
	if Input.GetKeyDown("Escape") or Input.GetButtonDown("Menu") then
		v560 = false
		v63 = false
		v549 = false
	end
	if v105 > v22 + 5000 then
		v22 = v105 + 20000
		local v415
		v415 = coroutine.create(function()
			local function v403(waittime)
				v333[v415] = v105 + waittime
				coroutine.yield()
			end
			GetCurrentWeapon()
			local v190 = GameObject.FindByName("Shaker")
			if v190 ~= nil then
				local v495 = v190.Transform.GetChild(0).GameObject
				local v358 = v495.GetComponent("PickUpInteract")
				if v358 ~= nil and v358.IsValid() then
					v358.Active = not (v532 and v114 or v137)
				end
			end
			local v60 = v409 and v409.GetField("LocalPlayer")
			if v60 ~= nil then
				local v26 = v60.GetAsUnknownType("CustomProperties")
				if v26 ~= nil then
					v532 = string.sub(basicModule.tostring(v60.GetField("IsMasterClient")), 16, - 2) == "True"
					v60.CallMethod("SetCustomProperties", v26, nil, nil)
					v60.SetField("i", v31)
				end
			end
			v403(0)
			if not v195 then
				return
			end
			for v531 = 1, # v511 do
				v403(0)
				local v633 = v511[v531]
				local v350 = v438(v633)
				if not v94[v350] then
					v94[v350] = {}
				end
				local v93 = v633.GetAsUnknownType("CustomProperties")
				v262[v350] = v93
				v94[v350].state = string.gsub(basicModule.tostring(v93.CallMethod("get_Item", "State")), "[\n><\\]", "")
				v94[v350].mods = string.gsub(basicModule.tostring(v93.CallMethod("get_Item", "Mods")), "[\n><\\]", "")
				v94[v350].host = string.sub(basicModule.tostring(v633.GetField("IsMasterClient")), 16, - 2) == "True"
				if v94[v350].host == true then
					local v74 = v93.CallMethod("get_Item", "GBRP")
					local v435 = GameObject.FindAllByComponent("AdditionalGamemodeMaster")
					if # v435 > 0 then
						local v89 = v435[1].Transform.Find("OS/GBRP")
						if v89 ~= nil then
							v89.GameObject.Active = v74
							v89.Parent.GameObject.Active = v74
						end
					end
					v451 = v93.CallMethod("get_Item", "Aircontrol")
					v502 = v93.CallMethod("get_Item", "ConditionLock")
					v176 = v93.CallMethod("get_Item", "BanJump")
					v137 = v93.CallMethod("get_Item", "BanGrab")
					v103 = v93.CallMethod("get_Item", "AllowHats")
					local v229 = GameObject.FindByName("Shaker")
					if v229 ~= nil then
						local v495 = v229.Transform.GetChild(0).GameObject
						local v358 = v495.GetComponent("PickUpInteract")
						if v358 ~= nil and v358.IsValid() then
							v358.Active = not v137
						end
					end
					if v363 == false and v103 == false then
						v526()
						if controllerObj ~= nil and controllerObj.IsValid() then
							local v594 = controllerObj.Transform.Find("BaseAI")
							if v594 ~= nil then
								local v656 = v594.GameObject
								v656.RPC("PutOnHatNew", nil, {
									- 1,
									0
								})
								v656.RPC("PutOnHatNew", nil, {
									- 1,
									1
								})
								v656.RPC("PutOnHatNew", nil, {
									- 1,
									2
								})
								v656.RPC("PutOnHatNew", nil, {
									- 1,
									3
								})
								v656.RPC("PutOnHatNew", nil, {
									- 1,
									4
								})
							end
						end
						v363 = true
					end
					if not v532 then
						v36 = v176
						v114 = v137
						v406 = v103
						v91 = v502
						v650 = v451
						v573 = v74
					end
				end
				if not v464[v350] then
					local v610 = basicModule.tostring(v93.CallMethod("get_Item", "CustomID"))
					local v386 = basicModule.tostring(v93.CallMethod("get_Item", "Color"))
					if v610 ~= "nil" then
						v94[v350].id = v610
						v633.SetField("Username", v350)
						v633.SetField("i", v386)
						v633.SetField("UserId", v610)
						v363 = false
						if v532 then
							local v593 = GameObject.FindAllByComponent("GameRules")
							if # v593 > 0 then
								local v160 = v593[1].GetComponent("GameRules")
								v160.CallMethod("SendSyncGamemode", v633)
							end
							local v278 = GameObject.FindAllByComponent("EnvironmentMaster")
							if # v278 > 0 then
								local v104 = v278[1].GetComponent("EnvironmentMaster")
								v104.CallMethod("SendSyncWeather", v633)
							end
							Server.SendChatMessage("<color=yellow>" .. v350 .. " 加入了服务器", 20)
							v210("<color=yellow>" .. v350 .. " 加入了服务器")
						end
						v464[v350] = true
					end
				end
			end
			v22 = Time.GetRealTimeMs()
		end)
		v333[v415] = 0
	end
	for corout, cortime in tableIterators.pairs(v333) do
		if v105 > cortime then
			v333[corout] = nil
			local v239, err = coroutine.resume(corout)
		end
	end
	if v105 > v385 + 20000 then
		v385 = v105
		v636 = math.ceil(1 / v368)
		local v8 = v64 .. " ms; " .. v636 .. " fps"
		local v60 = v409.GetField("LocalPlayer")
		local v26 = v60.GetAsUnknownType("CustomProperties")
		v244 = ""
		if v273 then
			local v115 = File.GetLoadedMods()
			for v531 = 1, # v115 do
				v244 = v244 .. (v531 ~= 1 and ", " or "") .. v115[v531]
			end
			if v244 == "" then
				v244 = "Unable to get mods list"
			end
		else
			local v115 = GameObject.FindAllByComponent("LuaScriptController")
			for v531 = 1, # v115 do
				v244 = v244 .. (v531 ~= 1 and ", " or "") .. string.sub(v115[v531].Name, 5)
			end
			if v244 == "" then
				v244 = "Unable to get mods list"
			end
		end
		if v26.CallMethod("ContainsKey", "Mods") then
			v26.CallMethod("set_Item", "Mods", v244)
		else
			v26.CallMethod("Add", "Mods", v244)
		end
		if v26.CallMethod("ContainsKey", "CustomID") then
			v26.CallMethod("set_Item", "CustomID", (string.gsub(basicModule.tostring(string.sub(Input.GetDeviceInfo().deviceUniqueIdentifier, 1, 24)), "[^%w]", "")))
		else
			v26.CallMethod("Add", "CustomID", (string.gsub(basicModule.tostring(string.sub(Input.GetDeviceInfo().deviceUniqueIdentifier, 1, 24)), "[^%w]", "")))
		end
		if v26.CallMethod("ContainsKey", "Color") then
			v26.CallMethod("set_Item", "Color", v31)
		else
			v26.CallMethod("Add", "Color", v31)
		end
		if v26.CallMethod("ContainsKey", "State") then
			v26.CallMethod("set_Item", "State", v8)
		else
			v26.CallMethod("Add", "State", v8)
		end
		if v26.CallMethod("ContainsKey", "GBRP") then
			v26.CallMethod("set_Item", "GBRP", v573)
		else
			v26.CallMethod("Add", "GBRP", v573)
		end
		if v26.CallMethod("ContainsKey", "Aircontrol") then
			v26.CallMethod("set_Item", "Aircontrol", v650)
		else
			v26.CallMethod("Add", "Aircontrol", v650)
		end
		if v26.CallMethod("ContainsKey", "ConditionLock") then
			v26.CallMethod("set_Item", "ConditionLock", v91)
		else
			v26.CallMethod("Add", "ConditionLock", v91)
		end
		if v26.CallMethod("ContainsKey", "BanJump") then
			v26.CallMethod("set_Item", "BanJump", v36)
		else
			v26.CallMethod("Add", "BanJump", v36)
		end
		if v26.CallMethod("ContainsKey", "BanGrab") then
			v26.CallMethod("set_Item", "BanGrab", v114)
		else
			v26.CallMethod("Add", "BanGrab", v114)
		end
		if v26.CallMethod("ContainsKey", "AllowHats") then
			v26.CallMethod("set_Item", "AllowHats", v406)
		else
			v26.CallMethod("Add", "AllowHats", v406)
		end
		v60.CallMethod("SetCustomProperties", v26, nil, nil)
	end
	if v36 and Input.GetButtonDown("Crouch") and PlayerMaster.Grounded then
		v526()
		if rigidComp ~= nil and rigidComp.IsValid() then
			rigidComp.SetField("velocity", rigidComp.GetField("velocity").Mul(0.1))
		end
	end
	if Input.GetKeyDown("T") then
		v275(true)
	end
	if Input.GetKeyUp("T") then
		v275(false)
	end
end
local v538 = true
local v565 = 0
local v73 = 800
function FixedUpdate()
	if PlayerMaster.IsValid() then
		if v91 == true then
			PlayerMaster.Condition = 1
		end
		if v36 then
			local v546 = PlayerMaster.Grounded
			if v546 == true and v538 == false then
				v526()
				if rigidComp ~= nil and rigidComp.IsValid() then
					local v178 = rigidComp.GetField("velocity")
					local v453 = math.sqrt(v178.x * v178.x + v178.z * v178.z)
					if v453 > 0.5 then
						local v183 = v105 - v565
						if v183 > v73 then
							PlayerMaster.Cripple = true
							rigidComp.SetField("velocity", v178.Mul(0.1))
							v333[coroutine.create(function()
								PlayerMaster.Cripple = false
							end)] = v105 + 2000
						elseif v183 > v73 * 0.6 then
							PlayerMaster.Cripple = true
							rigidComp.SetField("velocity", v178.Mul(0.5 + 0.5 - (v183 - v73 / 2) / (v73 / 2) * 0.5))
							v333[coroutine.create(function()
								PlayerMaster.Cripple = false
							end)] = v105 + (v183 - v73 / 2) / (v73 / 2) * 1250
						else
							rigidComp.SetField("velocity", v178.Mul((v73 - v183) / v73 - 0.2))
						end
					end
				end
			end
			if v546 ~= v538 then
				v538 = v546
				if v546 == false then
					v565 = v105
				end
			end
			if v36 and PlayerMaster.Cripple then
				v526()
				if rigidComp ~= nil and rigidComp.IsValid() then
					rigidComp.SetField("velocity", rigidComp.GetField("velocity").Mul(0.85))
				end
			end
		else
			v538 = true
		end
	end
end
function OnLocalSpawned()
	local v615 = GameObject.FindByName("InventoryInstances")
	if not v615 then
		return
	end
	for w = 0, v615.Transform.ChildCount - 1 do
		local v411 = v615.Transform.GetChild(w).GameObject
		if v671[v411.Name] then
			local v132 = v411.GetComponent("GBWeapon")
			local v666 = v132.GetField("WeaponInstance")
			for field, v545 in tableIterators.pairs(v671[v411.Name]) do
				v132.SetField(field, v545)
				v666.SetField(field, v545)
			end
		end
	end
	v363 = false
end
OnLocalSpawned()
local v295 = {}
local v641 = {}
local v212 = {
	[55] = true,
	[56] = true,
	[57] = true,
	[58] = true,
	[59] = true
}
function OnLocalDied()
	v333[coroutine.create(function()
		if v243 == nil or not v243.IsValid() then
			v243 = GameObject.FindByName("recoilEffect")
			if v243 ~= nil then
				v243 = v243.Transform
			end
		end
		if v243 ~= nil then
			for v531 = 0, v243.ChildCount - 1 do
				if v531 < 10 then
					local v411 = v243.GetChild(v531).GameObject
					if not v411.Active then
						local v373 = v411.GetComponent("GBWeapon")
						if v373 ~= nil then
							v373.CallMethod("Drop")
						end
					end
				end
			end
		end
	end)] = v105 + 100
end
function OnTakeDamage(damage, limb, shooter)
	local v600 = damage / (15 + damage)
	if v600 > 1 then
		v600 = 1
	end
	v600 = 1 - v600
	local v327 = Player.GetLocal()
	if v327 ~= nil and v327.IsValid() then
		local v414 = v327.GetCharacter()
		if v414 ~= nil and v414.IsValid() then
			v526()
			if rigidComp ~= nil and rigidComp.IsValid() then
				local v255 = rigidComp.GetField("velocity")
				v255.x = v255.x * v600
				v255.z = v255.z * v600
				rigidComp.SetField("velocity", v255)
			end
		end
	end
end
function OnWeaponFire()
	local v237 = GetCurrentWeapon()
	if v237 ~= nil then
		local v373 = v295[v237]
		if v373 == nil then
			v373 = v237.GetComponent("GBWeapon")
			v295[v237] = v373
		end
		if v373 ~= nil then
			local v647 = v641[v237]
			if v647 == nil then
				v647 = v373.GetField("WeaponInstance")
				v641[v237] = v647
			end
			if v212[v647.GetField("SoundID")] then
				v647.SetField("SoundRange", 50)
				v333[coroutine.create(function()
					v647.SetField("SoundRange", 250)
				end)] = 0
			end
		end
	end
end